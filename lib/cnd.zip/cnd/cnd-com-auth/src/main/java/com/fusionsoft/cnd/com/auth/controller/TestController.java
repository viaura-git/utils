package com.fusionsoft.cnd.com.auth.controller;

import com.fusionsoft.cnd.com.auth.domain.entity.User;
import com.fusionsoft.cnd.com.auth.repository.UserRepository;
import com.fusionsoft.cnd.com.auth.security.model.CustomUserDetails;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@RestController
@RequestMapping("/api/test")
@RequiredArgsConstructor
public class TestController {

    private final UserRepository userRepository;

    // === 로그인된 사용자가 자신의 정보를 가져오는 예제 ===
    @GetMapping("/me")
    public ResponseEntity<?> getMyInfo(@AuthenticationPrincipal CustomUserDetails principal) {
        log.debug("getMyInfo() start");

        User user = userRepository.findByUserId(principal.getUserId())
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        log.debug("Myinfo from RDB is {}", user);
        // 예시로 username, roles만 반환
        return ResponseEntity.ok(Map.of(
                "userId", user.getUserId(),
                "roles", user.getRoles().stream()
                        .map(r -> r.getRoleName().name())
                        .collect(Collectors.toList()),
                "username", user.getUserName(),
                "email", user.getEmail(),
                "phone", user.getPhone()
        ));
    }
}
