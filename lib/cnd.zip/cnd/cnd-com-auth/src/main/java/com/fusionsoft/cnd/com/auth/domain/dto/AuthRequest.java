package com.fusionsoft.cnd.com.auth.domain.dto;

public record AuthRequest(
        String userId, String password
) {
}
