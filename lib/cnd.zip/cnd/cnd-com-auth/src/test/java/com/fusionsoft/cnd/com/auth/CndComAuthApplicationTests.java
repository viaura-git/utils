package com.fusionsoft.cnd.com.auth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CndComAuthApplicationTests {

    @Test
    void contextLoads() {
    }

}
