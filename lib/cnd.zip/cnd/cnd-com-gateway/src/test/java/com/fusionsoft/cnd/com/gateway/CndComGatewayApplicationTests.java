package com.fusionsoft.cnd.com.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CndComGatewayApplicationTests {

    @Test
    void contextLoads() {
    }

}
