package com.fusionsoft.cnd.etc.openssl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CndEtcOpensslApplication {

    public static void main(String[] args) {
        SpringApplication.run(CndEtcOpensslApplication.class, args);
    }

}
