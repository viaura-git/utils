package com.fusionsoft.cnd.etc.openssl.util;

import java.nio.file.Files;
import java.nio.file.Path;
import java.security.interfaces.RSAPublicKey;
import com.nimbusds.jose.jwk.RSAKey;

public class PemToJwks {

    public static void main(String[] args) throws Exception {
        // public.pem 읽기
        String pubKeyContent = Files.readString(Path.of("C:/Users/이상민/IdeaProjects/cnd/openssl/public.pem"))
                .replaceAll("-----BEGIN PUBLIC KEY-----", "")
                .replaceAll("-----END PUBLIC KEY-----", "")
                .replaceAll("\\s", "");

        // Base64 디코딩
        byte[] decoded = java.util.Base64.getDecoder().decode(pubKeyContent);

        // RSAPublicKey 객체 생성
        java.security.spec.X509EncodedKeySpec spec = new java.security.spec.X509EncodedKeySpec(decoded);
        java.security.KeyFactory kf = java.security.KeyFactory.getInstance("RSA");
        RSAPublicKey pubKey = (RSAPublicKey) kf.generatePublic(spec);

        // JWK 생성
        RSAKey jwk = new RSAKey.Builder(pubKey)
                .keyID("dev-key-1")
                .build();

        // JWKS JSON 생성
        String jwksJson = "{ \"keys\": [" + jwk.toJSONString() + "] }";
        System.out.println(jwksJson);

        // 파일로 저장
        Files.writeString(Path.of("C:/Users/이상민/IdeaProjects/cnd/openssl/jwks.json"), jwksJson);
        System.out.println("jwks.json 생성 완료");
    }
}

