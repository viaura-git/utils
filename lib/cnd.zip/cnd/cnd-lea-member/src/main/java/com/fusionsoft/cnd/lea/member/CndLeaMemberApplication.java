package com.fusionsoft.cnd.lea.member;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CndLeaMemberApplication {

    public static void main(String[] args) {
        SpringApplication.run(CndLeaMemberApplication.class, args);
    }

}
