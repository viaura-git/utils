package com.fusionsoft.cnd.res.reserve;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CndResReserveApplication {

    public static void main(String[] args) {
        SpringApplication.run(CndResReserveApplication.class, args);
    }

}
