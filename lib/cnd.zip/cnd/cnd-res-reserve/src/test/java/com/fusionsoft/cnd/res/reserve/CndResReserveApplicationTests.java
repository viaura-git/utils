package com.fusionsoft.cnd.res.reserve;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CndResReserveApplicationTests {

    @Test
    void contextLoads() {
    }

}
