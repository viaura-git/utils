-- 1. 데이터베이스 생성
CREATE DATABASE han815 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

-- 2. 사용자 생성 및 권한 부여
GRANT ALL PRIVILEGES ON han815.* TO 'viaura'@'%';

-- 3. 권한 적용
FLUSH PRIVILEGES;