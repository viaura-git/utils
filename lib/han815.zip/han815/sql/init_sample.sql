-- 1. 총판 2개 등록
insert into dist (email, name, phone, reg_date)
values ('kana@naver.com', '가나총판', '111-2222-3333', now());

insert into dist (email, name, phone, reg_date)
values ('nara@naver.com', '나라총판', '111-3333-4444', now());

-- 2. site 각 2개씩 등록
insert into site (email, name, phone, reg_date, dist_id, enabled)
values ('a@naver.com', 'a 가맹점', '111-2222-3333', now(), 1, true);

insert into site (email, name, phone, reg_date, dist_id, enabled)
values ('b@naver.com', 'b 가맹점', '111-2222-3333', now(), 1, true);

insert into site (email, name, phone, reg_date, dist_id, enabled)
values ('c@naver.com', 'c 가맹점', '111-2222-3333', now(),2, true);
insert into site (email, name, phone, reg_date, dist_id, enabled)
values ('d@naver.com', 'd 가맹점', '111-2222-3333', now(), 2, true);

-- 3. kana 총판 관리자
INSERT INTO users (
    user_id, email, user_name, password, phone, dist_id, enabled, reg_date
) VALUES (
             'kana',
             'kana@naver.com',
             '홍길동',
             '$2a$10$7OJPaNi1GZmH4j6UT5AOyONuor9HXuaBYj1Ki0Vbpf8tKOJT10i42', -- "1234"
            '010-2222-3333',
             1,
             true,
          now()
);

-- 4. nara 사이트 관리자
INSERT INTO users (
    user_id, email, user_name, password, phone, dist_id, han815.users.site_id, enabled, reg_date
) VALUES (
             'c',
             'c@naver.com',
             '홍길동',
             '$2a$10$7OJPaNi1GZmH4j6UT5AOyONuor9HXuaBYj1Ki0Vbpf8tKOJT10i42', -- "1234"
             '010-2222-3333',
             1,
             1,
             true,
             now()
         );



INSERT INTO user_roles (user_roles.user_unique_id, role_name)
VALUES (1, 'ROLE_SITE');

in
