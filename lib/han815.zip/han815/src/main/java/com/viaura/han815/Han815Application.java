package com.viaura.han815;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Han815Application {

    public static void main(String[] args) {
        SpringApplication.run(Han815Application.class, args);
    }

}
