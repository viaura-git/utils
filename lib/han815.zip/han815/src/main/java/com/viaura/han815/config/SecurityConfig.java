package com.viaura.han815.config;

import com.viaura.han815.config.filter.PasswordChangeFilter;
import com.viaura.han815.config.handler.CustomAuthenticationSuccessHandler;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.security.servlet.PathRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import static org.springframework.security.config.Customizer.withDefaults;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final CustomAuthenticationSuccessHandler successHandler;

    @Bean
    @Order(1) // api security 먼저 적용
    public SecurityFilterChain apiSecurityFilterChain(HttpSecurity http) throws Exception {
        http
        .securityMatcher("/api/**", "/ws/**")              // /api/** 요청만 해당 체인에서 처리
        .csrf(AbstractHttpConfigurer::disable)   // CSRF 비활성화
                //이거 넣으면 siteId를 가지고 있는 auth를 원천 차단해버린다. api 도 auth 정보가 필요하다
        //.sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)) // 세션 비활성화
        .authorizeHttpRequests(auth -> auth.anyRequest().permitAll()); // 모든 요청 허용

        return http.build();
    }

    @Bean
    @Order(2)
    public SecurityFilterChain webSecurityFilterChain(HttpSecurity http) throws Exception {
        http
                .securityMatcher(request -> !request.getRequestURI().startsWith("/api/")) // /api/** 제외
                .csrf(AbstractHttpConfigurer::disable)
                .authorizeHttpRequests(auth -> auth
                    .requestMatchers("/api/**").permitAll()
                    .requestMatchers(PathRequest.toStaticResources().atCommonLocations()).permitAll()
                    .requestMatchers("/", "/login", "/signup", "/about","/check-session/**","/change-password").permitAll()
                    .requestMatchers("/dist/**").hasAnyRole("DIST", "ADMIN")
                    .requestMatchers("/site/**").hasAnyRole("SITE", "DIST", "ADMIN")
                    .requestMatchers("/user/**").hasAnyRole("USER", "SITE", "DIST", "ADMIN")
                    .requestMatchers("/hq/**").hasAnyRole("ADMIN")
//                  .requestMatchers("/**").hasRole("ADMIN")
                    .anyRequest().authenticated()
            )
            //.addFilterBefore(new PasswordChangeFilter(), UsernamePasswordAuthenticationFilter.class) //최초 로그인시 비밀번호 변경페이지로 가지만 뒤로, 혹은 URL을 직접 입력하면 로그인 상태로 보이는 부분 방지
//          .formLogin(withDefaults()); //SpringSecurity가 제공하는의 기본 로그인페이지 출력
            .formLogin(login -> login
                    .loginPage("/login")  // 커스텀 로그인 페이지 경로
                    .usernameParameter("username")
                    .passwordParameter("password")
                    .loginProcessingUrl("/login")  // form action이 이 경로여야 함
//                  .defaultSuccessUrl("/", true) // 이건 spring security 기본값이다. 로그인 성공 시 이동할 경로
                    .successHandler(successHandler) //ROLE에 따라 분기한다
                    .failureUrl("/login?error=true") // 실패 시 다시 로그인 페이지
                    .permitAll()
            )
            .logout(logout -> logout
                    .logoutUrl("/logout")
                    .logoutSuccessUrl("/")
                    .invalidateHttpSession(true)
                    .deleteCookies("JSESSIONID")
            )
            .sessionManagement(session -> session
                    .sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
                    .maximumSessions(1) // 최대 1명만 로그인 허용
                    .maxSessionsPreventsLogin(false) // 새로운 로그인 허용, 대신 기존 세션 만료됨. true이면 신규로그인 거부
                    .expiredUrl("/login?expired=true") // 세션 만료 시 이동할 URL
            );

        return http.build();
    }



    /**
     * PasswordEncoder
     * @return
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }
}


