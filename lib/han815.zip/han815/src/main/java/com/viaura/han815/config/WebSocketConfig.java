package com.viaura.han815.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        // 클라이언트가 연결할 엔드포인트
        registry.addEndpoint("/ws")  // 클라이언트 연결 주소: ws://서버주소/ws
                .setAllowedOriginPatterns("*")
                .withSockJS(); // SockJS fallback 지원 (옵션)
    }

    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        // 메시지 브로커 설정
        registry.enableSimpleBroker("/topic"); // 구독 경로 (브라우저가 구독할 주소 prefix)
        registry.setApplicationDestinationPrefixes("/app"); // 클라이언트가 서버로 메시지 보낼 때 사용, RequestMapping에서는 /app 경로가 생략된다
    }

}
