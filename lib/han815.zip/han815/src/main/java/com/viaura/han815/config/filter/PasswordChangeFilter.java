package com.viaura.han815.config.filter;

import com.viaura.han815.service.user.CustomUserDetails;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Slf4j
public class PasswordChangeFilter extends OncePerRequestFilter {

    private static final String CHANGE_PASSWORD_URI = "/change-password";

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        String path = request.getRequestURI();
        log.debug(">>> [PasswordChangeFilter] URI: {}", path);

        // 1. /api/** 는 무조건 통과시켜야 함
        if (path.startsWith("/api/")) {
            filterChain.doFilter(request, response);
            return;
        }

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        //2. 인증 안 된 경우도 통과시켜야 함
        if (auth == null || !auth.isAuthenticated()
                || auth instanceof AnonymousAuthenticationToken) {
            filterChain.doFilter(request, response);
            return;
        }

        //3. 사용자 인증된 경우에만 검사
        Object principal = auth.getPrincipal();
        if (principal instanceof CustomUserDetails userDetails) {
            if (userDetails.isFirstLogin()) {
                response.sendRedirect(CHANGE_PASSWORD_URI);
                return;
            }
        }

        filterChain.doFilter(request, response);
    }
}

