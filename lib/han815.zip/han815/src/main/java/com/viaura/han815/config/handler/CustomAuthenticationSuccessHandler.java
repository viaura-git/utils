package com.viaura.han815.config.handler;

import com.viaura.han815.domain.record.SessionUser;
import com.viaura.han815.service.user.CustomUserDetails;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@Slf4j
public class CustomAuthenticationSuccessHandler extends SavedRequestAwareAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request,
                                        HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {

        HttpSession session = request.getSession();

        // 사용자 정보 가져오기
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();

        log.debug("userDetails = " + userDetails.toString());

        // 역할 추출 (ROLE_ prefix 포함)
        Set<String> roles = authentication.getAuthorities()
                .stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.toSet());

        log.debug("roles = " + roles);
        log.debug("isFirstLogin = " + userDetails.isFirstLogin());

        if(userDetails.isFirstLogin()){
            response.sendRedirect("/change-password");
            return;
        }

        // 세션에 사용자 저장
        SessionUser sessionUser = new SessionUser(userDetails.getUserId(), userDetails.getUsername(), roles);
        log.debug("sessionUser = " + sessionUser);

        session.setAttribute(userDetails.getUserId(), sessionUser);

        this.setDefaultTargetUrl("/"); // 기본 리다이렉트 URL
        this.setAlwaysUseDefaultTargetUrl(false); // 이전 페이지 우선

        String redirectUrl = "/";
        // 역할에 따라 리다이렉트 (ADMIN > USER > fallback)
        if (roles.contains("ROLE_ADMIN")) {
            log.debug("----> admin login success. redirecting to /admin");
            redirectUrl = "/hq";
        } else if (roles.contains("ROLE_DIST")) {
            log.debug("Distributor logged in");
            redirectUrl = "/dist";
        } else if (roles.contains("ROLE_SITE")) {
            log.debug("Site Manager logged in");
            redirectUrl = "/site";
        } else if (roles.contains("ROLE_USER")) {
            log.debug("user");
            redirectUrl = "/user";
        }

        log.debug("redirectUrl : {} ", redirectUrl);
        response.sendRedirect(redirectUrl);
    }

}