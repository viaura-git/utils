package com.viaura.han815.controller;

import com.viaura.han815.domain.dto.UserSignupRequest;
import com.viaura.han815.domain.entity.Bank;
import com.viaura.han815.repository.BankRepository;
import com.viaura.han815.repository.UserRepository;
import com.viaura.han815.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class ApiCommonController {

    private final BankRepository bankRepository;
    private final UserService userService;

    @PostMapping("/signup")
    public ResponseEntity<?> signup(@RequestBody UserSignupRequest request) {
        userService.signup(request);
        return ResponseEntity.ok("회원가입 성공");
    }

    @GetMapping("/bank/{bankCode}")
    public ResponseEntity<Bank> getBank(@PathVariable String bankCode) {
        Bank bank = bankRepository.findById(bankCode).orElseThrow(() -> new ResourceNotFoundException("등록된 은행이 아닙니다"));
        return ResponseEntity.ok(bank);
    }

    @GetMapping("/banks")
    public ResponseEntity<List<Bank>> getAllBanks() {
        List<Bank> banks = bankRepository.findAllByOrderByNameAsc();
        log.debug("banks : {}", banks);

        return ResponseEntity.ok(banks);
    }
}
