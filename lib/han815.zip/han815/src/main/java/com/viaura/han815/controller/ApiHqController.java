package com.viaura.han815.controller;

import com.viaura.han815.domain.dto.TransactionSearchRecord;
import com.viaura.han815.repository.TransactionHistoryRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/api/hq")
public class ApiHqController {

    TransactionHistoryRepository transactionHistoryRepository;

    @RequestMapping("/transactions")
    public ResponseEntity<?> getTransactionHistory(TransactionSearchRecord dto,
//                                                  @AuthenticationPrincipal CustomUserDetails admin,
                                                  Pageable pageable) {

        return ResponseEntity.ok().body(transactionHistoryRepository.findAllByHq(dto.from(), dto.to(), pageable));
    }

}
