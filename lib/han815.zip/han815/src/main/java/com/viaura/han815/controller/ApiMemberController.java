package com.viaura.han815.controller;

import com.viaura.han815.domain.dto.MemberDepositAccountInfoRecord;
import com.viaura.han815.domain.dto.MemberRegisterRecord;
import com.viaura.han815.domain.dto.MemberSearchRequestRecord;
import com.viaura.han815.domain.dto.MemberStatusRecord;
import com.viaura.han815.domain.entity.Member;
import com.viaura.han815.domain.entity.Site;
import com.viaura.han815.domain.types.BankType;
import com.viaura.han815.event.EventPublisher;
import com.viaura.han815.repository.MemberRepository;
import com.viaura.han815.repository.TransactionHistoryRepository;
import com.viaura.han815.service.MemberService;
import com.viaura.han815.service.user.CustomUserDetails;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.PagedModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;

@Slf4j
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class ApiMemberController {

    private final MemberRepository memberRepository;
    private final TransactionHistoryRepository transactionHistoryRepository;
    private final MemberService memberService;

    private final EventPublisher eventPublisher;

    @GetMapping("/site/members")
    public ResponseEntity<?> findAllBySiteAndMemberIdContaining(@ModelAttribute MemberSearchRequestRecord dto,
                                                                @AuthenticationPrincipal CustomUserDetails user,
                                                                Pageable pageable,
                                                                PagedResourcesAssembler<Member> pagedAssembler) {
        log.debug("----> findAllBySiteAndMemberIdContaining()  start");
        Site site = user.getUser().getSite();
        log.debug("----> siteId : {}", site.getSiteId());
        log.debug("----> memberId : {}", dto.memberId());
        log.debug("----> StringUtils.hasText(memberId) : {}", StringUtils.hasText(dto.memberId()));
        log.debug("----> enabled : {}", dto.enabled());
        log.debug("----> deleted : {}", dto.deleted());

        log.debug("----> MemberSearchRequest dto : {}", dto.toString());

        Page<Member> members;

        if (dto.enabled() == null && dto.deleted() == null) {
            log.debug("1");
            if (!StringUtils.hasText(dto.memberId())) {
                log.debug("2");
                members = memberRepository.findBySite(site, pageable);
            } else {
                log.debug("3");
                members = memberRepository.findBySiteAndMemberIdContainingIgnoreCase(site, dto.memberId(), pageable);
            }
        } else if (dto.enabled() != null && dto.deleted() == null) {
            log.debug("4");
            if (!StringUtils.hasText(dto.memberId())) {
                log.debug("5");
                members = memberRepository.findBySiteAndEnabled(site, dto.enabled(), pageable);
            } else {
                log.debug("6");
                members = memberRepository.findBySiteAndMemberIdContainingIgnoreCaseAndEnabled(site, dto.memberId(), dto.enabled(), pageable);
            }
        } else if (dto.enabled() == null && dto.deleted() != null) {
            if (!StringUtils.hasText(dto.memberId())) {
                log.debug("7");
                members = memberRepository.findBySiteAndDeleted(site, dto.deleted(), pageable);
            } else {
                log.debug("8");
                members = memberRepository.findBySiteAndMemberIdContainingIgnoreCaseAndDeleted(site, dto.memberId(), dto.deleted(), pageable);
            }
        } else {
            if (!StringUtils.hasText(dto.memberId())) {
                log.debug("9");
                members = memberRepository.findBySiteAndEnabledOrDeleted(site, dto.enabled(), dto.deleted(), pageable);
            } else {
                log.debug("10");
                members = memberRepository.findBySiteAndMemberIdContainingIgnoreCaseAndEnabledOrDeleted(site, dto.memberId(), dto.enabled(), dto.deleted(), pageable);
            }
        }


        // HATEOAS 적용: 각 Member를 EntityModel로 감싸고, Page 정보를 PagedModel로 변환
        PagedModel<EntityModel<Member>> pagedModel = pagedAssembler.toModel(members,
                member -> EntityModel.of(member,
                        WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(ApiMemberController.class)
                                .findMember(member.getMId())).withSelfRel()
                )
        );
        log.debug("----> pagedModel : {}", pagedModel);

        return ResponseEntity.ok(pagedModel);


//        eventPublisher.publishMemberFindEvent(site.getSiteId(), memberId, "를 찾았습니다");
    }

    @GetMapping("/site/members/{id}")
    public ResponseEntity<?> findMember(@PathVariable Long id) {
        Member member = memberRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "회원을 찾을 수 없습니다"));
        return ResponseEntity.ok(EntityModel.of(member));
    }


    @PostMapping("/site/members")
    public ResponseEntity<?> registerMember(@Valid @RequestBody MemberRegisterRecord record, @AuthenticationPrincipal CustomUserDetails user) {
        log.debug("----> member record : {}", record);
        Member saved = memberService.save(record, user);
        log.debug("---- member saved : {}", saved);
        return ResponseEntity.ok(saved);
    }

    @PatchMapping("/site/members/{mId}/status")
    public ResponseEntity<?> updateMemberStatus(@Valid @PathVariable Long mId,
                                          @RequestBody MemberStatusRecord dto,
                                          @AuthenticationPrincipal CustomUserDetails user) {
        log.debug("----> mId : {}", mId);
        log.debug("----> MemberStatusRecord record : {}", dto);
        Site site = user.getUser().getSite();
        log.debug("----> siteId : {}", site.getSiteId());
        Member member = memberRepository.findById(mId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "회원정보를 찾을 수 없습니다"));

        if(dto.enabled() != null) member.setEnabled(dto.enabled());
        if(dto.deleted() != null) {
            member.setDeleted(dto.deleted());

            if(StringUtils.hasText(member.getDepositBankAccount())) {
                member.setDepositBankAccount(null);
                member.setDepositBankCode(null);
                member.setDepositBankName(null);
            }
        }

        return ResponseEntity.ok(memberRepository.save(member));
    }

    @PatchMapping("/site/members/{mId}/depositInfo")
    public ResponseEntity<?> updateMemberDepositInfo(@Valid @PathVariable Long mId,
                                                @RequestBody MemberDepositAccountInfoRecord dto,
                                                @AuthenticationPrincipal CustomUserDetails user) {
        log.debug("----> mId : {}", mId);
        log.debug("----> MemberStatusRecord record : {}", dto);
        Site site = user.getUser().getSite();
        log.debug("----> siteId : {}", site.getSiteId());
        Member member = memberRepository.findById(mId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "회원정보를 찾을 수 없습니다"));

        member.setDepositBankCode(dto.depositBankCode());
        member.setDepositBankAccount(dto.depositBankAccount());

        if(dto.depositBankAccount() != null) {
            BankType bank = BankType.fromCode(dto.depositBankCode()).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "은행 정보를 찾을 수 없습니다"));
            member.setDepositBankName(bank.getName());
        } else member.setDepositBankName(dto.depositBankName());

        member.setDepositBankAccountPeriodFrom(dto.depositBankAccountPeriodFrom());
        member.setDepositBankAccountPeriodTo(dto.depositBankAccountPeriodTo());

        return ResponseEntity.ok(memberRepository.save(member));
    }


    @GetMapping("/site/members/check-duplicate")
    public ResponseEntity<?> duplicateMember(@RequestParam String memberId, Authentication auth) {
        log.debug("----> memberId : {}", memberId);
        // 1. 인증 체크
        if (auth == null || !auth.isAuthenticated()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("로그인이 필요합니다");
        }

        // 2. memberId 형식 검증
        if (!memberId.matches("^[a-zA-Z0-9]{4,15}$")) {
            return ResponseEntity.badRequest()
                    .body("아이디는 4~15자의 영문자와 숫자만 포함해야 합니다.");
        }

        // 3. 중복 확인
        Boolean exists = memberService.existsBySiteAndMemberId(memberId, auth);
        log.debug("----> exists : {}", exists);
        return ResponseEntity.ok(exists);
    }


}
