package com.viaura.han815.controller;

import com.viaura.han815.service.UserService;
import com.viaura.han815.service.user.CustomUserDetails;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/api")
@RestController
@RequiredArgsConstructor
public class ApiSiteController {

    private final UserService userService;

    @GetMapping("/site/users")
    public ResponseEntity<?> getUser(@RequestParam String userId,
                                  @AuthenticationPrincipal CustomUserDetails user) {

        return ResponseEntity.ok(userService.findBySiteAndUserId(user.getUser().getSite(), userId));
    }
}
