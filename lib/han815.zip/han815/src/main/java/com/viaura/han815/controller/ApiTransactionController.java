package com.viaura.han815.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.viaura.han815.domain.dto.*;
import com.viaura.han815.domain.entity.Dist;
import com.viaura.han815.domain.entity.Site;
import com.viaura.han815.domain.entity.TransactionHistory;
import com.viaura.han815.domain.types.TransactionType;
import com.viaura.han815.repository.SiteRepository;
import com.viaura.han815.repository.TransactionHistoryRepository;
import com.viaura.han815.service.TransactionHistoryService;
import com.viaura.han815.service.user.CustomUserDetails;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.PagedModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.beans.PropertyEditorSupport;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Slf4j
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class ApiTransactionController {

    @Autowired
    private ObjectMapper objectMapper; // bean 등록되어 있어야 합니다

    private final TransactionHistoryService transactionHistoryService;
    private final SiteRepository siteRepository;
    private final TransactionHistoryRepository transactionHistoryRepository;

    //가상계좌 입금 API
    @PostMapping("/site/deposit")
    public ResponseEntity<TransactionHistory> saveDeposit(@Valid @RequestBody DepositRequestRecord request) {
        log.debug("------> Deposit request: {}", request);
        Site site = siteRepository.findById(request.siteId()).orElseThrow(() -> new IllegalArgumentException("Site not found"));
        Dist dist = site.getDist();
        TransactionHistory saved = transactionHistoryService.save(request.toEntity(site));
        return ResponseEntity.ok(saved);
    }

    //회원 출금요청 API
    @PostMapping("/site/withdraw")
    public ResponseEntity<TransactionHistory> saveWithdraw(@Valid @RequestBody WithdrawalRequestRecord request,
                                                           @AuthenticationPrincipal CustomUserDetails customUserDetails) {
        log.debug("------> Withdraw request: {}", request);

        Site site = customUserDetails.getUser().getSite();
        Dist dist = site.getDist();
        TransactionHistory withdrawal = request.toEntity(site, dist);
        withdrawal.setWithdrawalStatus("NEW");
        TransactionHistory saved = transactionHistoryService.save(withdrawal);
        log.debug("------> Withdraw saved: {}", saved);

        return ResponseEntity.ok(saved);
    }

    @PatchMapping("/site/withdraw")
    public ResponseEntity<?> confirmWithdraw(@RequestBody WithdrawalPatchRecord request,
                                            @AuthenticationPrincipal CustomUserDetails user) {
        Site site = user.getUser().getSite();
        Dist dist = site.getDist();
        TransactionHistory transactionHistory = transactionHistoryRepository.findById(request.tId()).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        TransactionHistory updated;

        // validation logic
        if(site.getSiteId().equals(transactionHistory.getSiteId()) &&
                dist.getDistId().equals(transactionHistory.getDistId()) &&
                request.tId().equals(transactionHistory.getTId())) {

            transactionHistory.setWithdrawalStatus("CONFIRMED");
            updated = transactionHistoryRepository.save(transactionHistory);

        } else throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
        log.debug("------> Withdraw updated: {}", updated);

        return ResponseEntity.ok(updated);
    }


    // 네이밍 규칙 /site/transaction... 으로 시작하면 deposit과 withdrawal 을 parameter 구분을 통해 모두 검색 가능하다
    @GetMapping("/site/transaction/history")
    public ResponseEntity<?> findTransactionHistoriesByCondition(@AuthenticationPrincipal CustomUserDetails user,
                                                             @ModelAttribute TransactionSearchRecord dto,
                                                             Pageable pageable,
                                                             PagedResourcesAssembler<TransactionHistoryRecord> pagedAssembler) {

        TransactionSearchCondition condition = dto.toEntity();

        Long siteId = user.getSiteId();
        condition.setSiteId(siteId);
        log.debug("------> findTransactionHistoriesByCondition start: {}", condition);

        Page<TransactionHistoryRecord> transactions = transactionHistoryService.findTransactionsWithCondition(condition, pageable);

        // HATEOAS 변환
        PagedModel<EntityModel<TransactionHistoryRecord>> pagedModel = pagedAssembler.toModel(transactions,
                transaction -> EntityModel.of(transaction,
                        WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(ApiTransactionController.class)
                                        .findTransactionById(transaction.tId()))
                                .withSelfRel()
                )
        );

        return ResponseEntity.ok(pagedModel);
    }

    @GetMapping("/site/transaction/history/member/{id}")
    public ResponseEntity<?> findTransactionById(@PathVariable Long id) {
        TransactionHistory deposit = transactionHistoryRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "입금 내역이 없습니다"));
        return ResponseEntity.ok(EntityModel.of(deposit));
    }

    //TransactionType 이 html 에서 소문자로 올 경우를 대비한 initBinder.
    //deposit, withdrawal 로 오면 toUpperCase() 로 변환해준다
    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.registerCustomEditor(TransactionType.class, new PropertyEditorSupport() {
            @Override
            public void setAsText(String text) {
                if (text != null) {
                    setValue(TransactionType.valueOf(text.toUpperCase()));
                }
            }
        });
    }


    @GetMapping("/site/transactions/chart/today")
    public ResponseEntity<List<TransactionHourlySummaryRecord>> getTodayChart(@AuthenticationPrincipal CustomUserDetails user) {
        Long siteId = user.getSiteId();

        List<TransactionHourlySummaryRecord> chartData = transactionHistoryService.findTodayHourlyTransactionsGroupedByType(siteId);
        return ResponseEntity.ok(chartData);
    }

    //가맹점 입금내역 혹은 출금내역
    @GetMapping("/site/transaction/amount")
    public ResponseEntity<Map<String, Long>> sumDepositAmount(@AuthenticationPrincipal CustomUserDetails user,
                                                               @ModelAttribute TransactionSearchRecord dto){


        log.debug("------> sumDepositAmount start dto : {}", dto);

        TransactionSearchCondition condition = dto.toEntity();
        Long siteId = user.getSiteId();
        condition.setSiteId(siteId);

        log.debug("------> sumDepositAmount condition: {}", condition);



        Long totalAmount = transactionHistoryService.sumAmountsWithCondition(condition);
        log.debug("----> totalAmount : {}", totalAmount);
        if(totalAmount == null) totalAmount = 0l;

        //총판 수수료, 본사 수수료 구분 및 계산로직
        BigDecimal amount = BigDecimal.valueOf(totalAmount);

        BigDecimal distRate = user.getUser().getSite().getCommRate(); // 예: 5.00 (%)
        BigDecimal distFee = amount.multiply(distRate)
                .divide(BigDecimal.valueOf(100))
                .setScale(0, RoundingMode.HALF_UP);

        BigDecimal hqRate = user.getUser().getSite().getDist().getCommRate(); // 예: 10.00 (%)
        BigDecimal hqFee = amount.multiply(hqRate)
                .divide(BigDecimal.valueOf(100))
                .setScale(0, RoundingMode.HALF_UP);

        Long commFee = distFee.add(hqFee).longValue(); // 소수점 버림 (필요하면 반올림 처리 가능)
        log.debug("------> commFee : {}", commFee);

        return ResponseEntity.ok(
                Map.of(
                "totalAmount", totalAmount,
                "commFee", commFee
                )
        );
    }

    @GetMapping("/site/balance")
    public ResponseEntity<?> getSiteBalance(@AuthenticationPrincipal CustomUserDetails user) {
        log.debug("------> getSiteBalance() start");

        Long siteBalance = transactionHistoryRepository.sumBalanceBySite(user.getSiteId());
        return ResponseEntity.ok(siteBalance);

    }



    //가맹점 입금내역 혹은 출금내역
    /**
    @GetMapping("/hq/transaction/amount")
    public ResponseEntity<Map<String, Long>> sumHqTransactionAmounts(@AuthenticationPrincipal CustomUserDetails user,
                                                              @ModelAttribute TransactionSearchRecord dto){


        log.debug("------> sumHqTransactionAmounts start dto : {}", dto);

        TransactionSearchCondition condition = dto.toEntity();
        Long siteId = user.getSiteId();
        condition.setSiteId(siteId);

        log.debug("------> sumHqTransactionAmounts condition: {}", condition);



        Long totalDeposits = transactionHistoryService.sumHqAmountsWithCondition(condition);
        log.debug("----> totalAmount : {}", totalAmount);
        if(totalAmount == null) totalAmount = 0l;

        //총판 수수료, 본사 수수료 구분 및 계산로직
        BigDecimal amount = BigDecimal.valueOf(totalAmount);

        BigDecimal distRate = user.getUser().getSite().getCommRate(); // 예: 5.00 (%)
        BigDecimal distFee = amount.multiply(distRate)
                .divide(BigDecimal.valueOf(100))
                .setScale(0, RoundingMode.HALF_UP);

        BigDecimal hqRate = user.getUser().getSite().getDist().getCommRate(); // 예: 10.00 (%)
        BigDecimal hqFee = amount.multiply(hqRate)
                .divide(BigDecimal.valueOf(100))
                .setScale(0, RoundingMode.HALF_UP);

        Long commFee = distFee.add(hqFee).longValue(); // 소수점 버림 (필요하면 반올림 처리 가능)
        log.debug("------> commFee : {}", commFee);

        return ResponseEntity.ok(
                Map.of(
                        "totalAmount", totalAmount,
                        "commFee", commFee
                )
        );
    }
                                                              **/


    /**
    @PreAuthorize("hasAnyRole('SITE', 'DIST', 'ADMIN')")
    @GetMapping("/deposit/history")
    public List<DepositHistoryRecord> getRecentDepositHistories() {
        return depositService.findTop10ByOrderByRegDateDesc();
    }**/
}
