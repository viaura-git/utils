package com.viaura.han815.controller;

import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.viaura.han815.domain.dto.DepositRequestRecord;
import com.viaura.han815.domain.entity.Dist;
import com.viaura.han815.domain.entity.Site;
import com.viaura.han815.domain.entity.TransactionHistory;
import com.viaura.han815.domain.record.SessionUser;
import com.viaura.han815.repository.SiteRepository;
import com.viaura.han815.service.SiteService;
import com.viaura.han815.service.TransactionHistoryService;
import com.viaura.han815.service.user.CustomUserDetails;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class DeveloperController {

    private final SiteService siteService;
    private final SiteRepository siteRepository;
    private final TransactionHistoryService transactionHistoryService;

    @Autowired
    private ObjectMapper mapper;

    @PostMapping("/dev/load-deposits")
    public ResponseEntity<String> loadDepositsFromJson() {
        log.debug("----> loadDepositsFromJson start");
        try(InputStream inputStream = getClass().getClassLoader().getResourceAsStream("deposit_history_minus_50.json")) {
            if(inputStream == null) {
                return ResponseEntity.notFound().build();
            }

            List<DepositRequestRecord> records = mapper.readValue(
                    inputStream, new TypeReference<>() {}
            );

            List<TransactionHistory> entities = records.stream().map(record -> {

                log.debug("----> loadDepositsFromJson record {}", record);

                Site site = siteRepository.findById(record.siteId()).orElseThrow(() -> new IllegalArgumentException("Site not found"));
                Dist dist = site.getDist();

                log.debug("toEntity Site : {}", site);
                log.debug("toEntity Dist : {}", dist);

                if(dist == null) { throw new IllegalArgumentException("No Dist linked to Site ID"); }


                return record.toEntity(site);

            }).collect(Collectors.toList());

            transactionHistoryService.saveAll(entities);

            return ResponseEntity.ok("총 " + records.size() + "건 저장완료");
        } catch (StreamReadException | DatabindException e) {
            log.error(e.getMessage());
            throw new RuntimeException(e);
        } catch (IOException e) {
            log.error("JSON 로딩 실패");
            return ResponseEntity.internalServerError().body("파일 로딩 실패");
        }
    }

    @GetMapping("/check-session/{userId}")
    public ResponseEntity<SessionUser> checkSession(@PathVariable String userId, HttpSession session) {
        SessionUser user = (SessionUser) session.getAttribute(userId);
        if(user == null) {throw new ResponseStatusException(HttpStatus.NOT_FOUND);}
        return ResponseEntity.ok(user);
    }

    @GetMapping("/dev/sites")
    public List<Long> findAllSites(@AuthenticationPrincipal CustomUserDetails user) {
        return siteService.findAllSiteIds(true);
    }
}
