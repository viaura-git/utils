package com.viaura.han815.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/dist")
public class DistController {

    @GetMapping("")
    public String distIndex(){
        return "dist/index";
    }
}
