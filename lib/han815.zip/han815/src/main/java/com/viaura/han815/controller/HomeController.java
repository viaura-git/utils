package com.viaura.han815.controller;

import com.viaura.han815.domain.dto.UserSignupRequest;
import com.viaura.han815.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@Slf4j
@Controller
@RequiredArgsConstructor
public class HomeController {

    private final AuthenticationManager authenticationManager;
    private UserService userService;

    @GetMapping("/")
    public String index() {
      log.info("/ ---> welcome home");
        return "index";
    }

    @GetMapping("/login")
    public String formlogin() {
        return "login";
    }

    /**
     * Spring Security 에서 제공하는 로그인 프로세스를 우회한다.
     * http.formLogin().disable() 을 해야하며, 이는 SecurityConfig 클래스에 적용한 CustomAuthenticationSuccessHandler 를 사용하지 못함을 의미한다
     * 그 내용을 모두 Controller에 담아 처리해야 하므로, @Valid 쓰자고 이렇게 할 이유가 없다
     * javascript 만으로 처리하는게 훨씬 효율적이다
    @PostMapping("/login")
    public String loginSubmit(
            @Valid @ModelAttribute("loginRequest") UserLoginRequest dto,
            BindingResult bindingResult,
            HttpServletRequest request,
            HttpServletResponse response
    ) {
        if (bindingResult.hasErrors()) {
            return "login";
        }

        try {
            UsernamePasswordAuthenticationToken token =
                    new UsernamePasswordAuthenticationToken(dto.username(), dto.password());

            Authentication auth = authenticationManager.authenticate(token);
            SecurityContextHolder.getContext().setAuthentication(auth);

            return "redirect:/"; // 로그인 성공 시 홈으로
        } catch (AuthenticationException ex) {
            bindingResult.reject("login.failed", "아이디 또는 비밀번호가 잘못되었습니다.");
            return "login";
        }
    }**/


    @GetMapping("/about")
    public String formAbout() {
        return "about";
    }

    @GetMapping("/signup")
    public String formSignup(@ModelAttribute("userSignupRequest") UserSignupRequest dto) {
        return "signup";
    }

    @PostMapping("/signup")
    public String signup(@Valid @ModelAttribute("userSignupRequest") UserSignupRequest userSignupRequest,
                         BindingResult bindingResult) {
        log.debug("/ ---> signup");
        log.debug("/ ---> userSignupRequest: {}", userSignupRequest);
        log.debug("/ ---> bindingResult: {}", bindingResult.toString());

        if (bindingResult.hasErrors()) {
            return "signup";
        }
//        userService.signup(userSignupRequest);
        return "signup";
    }

    @PostMapping("/change-password")
    public String changePassword(@RequestParam String newPassword, Principal principal) {
        userService.updatePassword(principal.getName(), newPassword);
        return "redirect:/";
    }

    @GetMapping("/change-password")
    public String changePassword(){
        return "/change-password";
    }
}
