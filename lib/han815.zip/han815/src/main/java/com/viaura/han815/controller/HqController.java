package com.viaura.han815.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.session.Session;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.security.Principal;
import java.util.Collection;

@Slf4j
@Controller
@RequestMapping("/hq")
public class HqController {

    @Autowired
    FindByIndexNameSessionRepository<? extends Session> sessions;

    @GetMapping("")
    public String hqIndex(Principal principal, Model model) {
        log.debug("/hq ---> hq controller index");
        log.debug("principal : {}", principal);

        Collection<? extends Session> usersSessions = this.sessions.findByPrincipalName(principal.getName()).values();

        if(usersSessions.isEmpty()) {
            log.debug("----> no sessions found");
        }

        usersSessions
                .forEach(session -> {
                    log.debug("Session ID: {}", session.getId());
                    log.debug("Creation Time: {}", session.getCreationTime());
                    log.debug("Last Accessed Time: {}", session.getLastAccessedTime());
                    log.debug("Max Inactive Interval: {}", session.getMaxInactiveInterval());
                    log.debug("Is Expired: {}", session.isExpired());

                    session.getAttributeNames().forEach(attrName ->
                            log.debug("Attribute [{}] = {}", attrName, session.getAttribute(attrName))
                    );

                    log.debug("--------");
                });

        model.addAttribute("sessions", usersSessions);

        log.debug("sessions in model : {}", usersSessions);
        model.addAttribute("fragmentName", "index");

        return "hq/index";

        /**
        SessionUser user = (SessionUser) sessions.getAttribute(userId);
        log.debug("/admin ---> admin controller session user");

        model.addAttribute("username", user.userId());
        model.addAttribute("isAdmin", user.roles().contains("ROLE_ADMIN"));
        model.addAttribute("isUser", user.roles().contains("ROLE_USER"));
         **/

    }

    @GetMapping("/dists")
    public String getDists(Model model){
        model.addAttribute("fragmentName", "dists");
        return "hq/index";
    }
    @GetMapping("/transactions")
    public String getDeposits(Model model){
        model.addAttribute("fragmentName", "transactions");
        return "hq/index";
    }

}
