package com.viaura.han815.controller;

import com.viaura.han815.domain.dto.TransactionHistoryRecord;
import com.viaura.han815.domain.dto.TransactionSearchCondition;
import com.viaura.han815.domain.entity.Member;
import com.viaura.han815.domain.entity.TransactionHistory;
import com.viaura.han815.repository.MemberRepository;
import com.viaura.han815.service.TransactionHistoryService;
import com.viaura.han815.service.user.CustomUserDetails;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Slf4j
@Controller()
@RequestMapping("/site")
@RequiredArgsConstructor
public class SiteController {

    private final MemberRepository memberRepository;
    private final TransactionHistoryService transactionHistoryService;

    @GetMapping("")
    public String index(Model model) {
        model.addAttribute("fragmentName", "dashboard");
        return "site/index";
    }

    @GetMapping("/withdraw")
    public String siteWithdraw(Model model, @AuthenticationPrincipal CustomUserDetails customUserDetails) {
        model.addAttribute("fragmentName", "site-withdraw");
        return "site/withdrawal";
    }

    @GetMapping("/members/deposits")
    public String deposit(Model model) {
        model.addAttribute("fragmentName", "deposit");
        return "site/deposit";
    }

    //회원출금 내역
    @GetMapping("/members/withdrawals")
    public String withdrawal(Model model) {
        model.addAttribute("fragmentName", "member-withdrawals");
        return "site/withdrawal";
    }

    //회원 출금요청
    @GetMapping("/members/withdraw")
    public String withdraw(Model model) {
        model.addAttribute("fragmentName", "member-withdraw");
        return "site/withdrawal";
    }

    //member-list
    @GetMapping("/members")
    public String members() {
        log.debug("-----> /site/members/enabled start");
        return "site/member";
    }

    //member-register
    @GetMapping("/members/register")
    public String register(Model model) {
        log.debug("-----> /site/members/register start");
        model.addAttribute("fragmentName", "register");
        return "site/member";
    }

    //member-detail
    @GetMapping("/members/{mId}")
    public String showMemberByMid(Model model, @PathVariable Long mId,
                             @AuthenticationPrincipal CustomUserDetails user,
                             Pageable pageable) {
        log.debug("-----> /site/members/{mId} start");
        model.addAttribute("fragmentName", "detail");

        Member member = memberRepository.findById(mId).get();
        model.addAttribute("member", member);

        return "site/member";
    }

    @GetMapping(value = "/members", params = "memberId")
    public String showMemberByMemberId(@RequestParam String memberId,
                                       Model model,
                                       @AuthenticationPrincipal CustomUserDetails user) {
        log.debug("-----> /site/members?memberId=xxx start");
        model.addAttribute("fragmentName", "detail");

        Member member = memberRepository.findBySiteAndMemberId(user.getUser().getSite(), memberId);
        model.addAttribute("member", member);

        return "site/member";
    }

    /**
    @PreAuthorize("hasRole('SITE', 'DIST', 'ADMIN')")
    @GetMapping("/deposit-history")
    public String depositHistory(Model model){
        List<DepositHistoryRecord> deposits = depositService.findTop10ByOrderByRegDateDesc();
        model.addAttribute("deposits", deposits);
        return "deposit-history-content";
    }**/


}
