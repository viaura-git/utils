package com.viaura.han815.domain.dto;


import com.viaura.han815.domain.entity.Dist;
import com.viaura.han815.domain.entity.Site;
import com.viaura.han815.domain.entity.TransactionHistory;
import com.viaura.han815.domain.types.TransactionType;
import jakarta.persistence.Column;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;

public record DepositRequestRecord(

        @NotBlank(message = "입금 출금 구분은 필수입니다")
        String type,

        @NotBlank(message = "입금자/출금자 아이디는 필수입니다")
        String memberId,

        @NotBlank(message = "입금자/출금자 이름은 필수입니다")
        String memberName,

        @NotNull(message = "충전금액은 필수입니다")
        @Min(value = 1, message = "충전금액은 1 이상이어야 합니다")
        Long amount,

        String depositPaymentId,

        String depositPaymentCompanyId,

        @NotNull(message = "가상계좌 은행명은 필수입니다")
        String depositBankName,

        @NotNull(message = "가상계좌 은행코드는 필수입니다")
        String depositBankCode,

        @NotNull(message = "가상계좌는 필수입니다")
        String depositBankAccount,

        LocalDateTime depositBankAccountPeriodFrom,

        LocalDateTime depositBankAccountPeriodTo,

        @Column(name = "DEPOSIT_DATE")
        LocalDateTime depositDate,

        @NotNull(message = "사이트 ID는 필수입니다")
        Long siteId,

        Long distId,

        LocalDateTime regDate

) {
        public TransactionHistory toEntity(Site site) {
                BigDecimal amount = BigDecimal.valueOf(this.amount());

                BigDecimal distRate = site.getCommRate(); // 예: 5.00 (%)
                BigDecimal distFee = amount.multiply(distRate)
                        .divide(BigDecimal.valueOf(100))
                        .setScale(0, RoundingMode.HALF_UP);

                Dist dist = site.getDist();

                BigDecimal hqRate = dist.getCommRate(); // 예: 10.00 (%)
                BigDecimal hqFee = amount.multiply(hqRate)
                        .divide(BigDecimal.valueOf(100))
                        .setScale(0, RoundingMode.HALF_UP);

                BigDecimal balance = amount.subtract(distFee).subtract(hqFee);

                return TransactionHistory.builder()
                        .type(TransactionType.fromValue(this.type())
                                .orElseThrow(() -> new IllegalArgumentException("Invalid TransactionType: " + this.type())))
                        .memberId(this.memberId())
                        .memberName(this.memberName())
                        .depositPaymentCompanyId(this.depositPaymentCompanyId())
                        .depositPaymentId(this.depositPaymentId())
                        .amount(this.amount())

                        .depositBankName(this.depositBankName())
                        .depositBankCode(this.depositBankCode())
                        .depositBankAccount(this.depositBankAccount())
                        .depositBankAccountPeriodFrom(this.depositBankAccountPeriodFrom())
                        .depositBankAccountPeriodTo(this.depositBankAccountPeriodTo())
                        .depositDate(this.depositDate())

                        .siteId(this.siteId())
                        .distId(this.distId())
                        .regDate(this.regDate())

                        .distCommRate(distRate)
                        .distCommFee(distFee)
                        .hqCommRate(hqRate)
                        .hqCommFee(hqFee)
                        .balance(balance)

                        .build();

        }
}

