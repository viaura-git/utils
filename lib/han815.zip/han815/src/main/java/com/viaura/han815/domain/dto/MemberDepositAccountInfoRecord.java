package com.viaura.han815.domain.dto;

import java.time.LocalDateTime;

public record MemberDepositAccountInfoRecord(
        String depositBankName, //가상계좌 등록시 추가
        String depositBankCode, //가상계좌 등록시 추가
        String depositBankAccount, //가상계좌 등록시 추가
        LocalDateTime depositBankAccountPeriodFrom,
        LocalDateTime depositBankAccountPeriodTo
) {
}
