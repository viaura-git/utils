package com.viaura.han815.domain.dto;

import com.viaura.han815.domain.entity.Dist;
import com.viaura.han815.domain.entity.Member;
import com.viaura.han815.domain.entity.Site;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import org.hibernate.validator.constraints.Length;

import java.time.LocalDateTime;

public record MemberRegisterRecord(

        Long mId,

        @NotBlank
        @Pattern(
            regexp = "^[a-zA-Z0-9]{4,15}$",
            message = "아이디는 4~15자의 영문자와 숫자만 입력해야 합니다."
        )
        String memberId,

        @NotBlank
        @Pattern(
            regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[\\W_]).{8,15}$",
            message = "비밀번호는 8~15자이며, 대문자, 소문자, 숫자, 특수문자를 모두 포함해야 합니다."
        )
        String password,

        @NotBlank @Pattern(regexp = "^010-\\d{4}-\\d{4}$", message = "전화번호 형식은 010-0000-0000 이어야 합니다.")
        String phone,

        @NotBlank String bankCode,

        @NotBlank @Pattern(regexp = "^[0-9\\-]+$", message = "전화번호는 숫자와 하이픈(-)만 입력 가능합니다.")
        String bankAccount,

        @NotBlank @Pattern(regexp = "^[가-힣a-zA-Z]+$", message = "한글과 영문자만 입력 가능합니다.")
        String bankAccountHolder,

        @NotBlank @Length(min = 6, max = 10)
        String bankIdentifier,

        Site site,
        Dist dist, // service에서 추가
        String depositBankName, //가상계좌 등록시 추가
        String depositBankCode, //가상계좌 등록시 추가
        String depositBankAccount, //가상계좌 등록시 추가
        LocalDateTime depositBankAccountPeriodFrom,
        LocalDateTime depositBankAccountPeriodTo,
        Boolean enabled,
        Boolean deleted
) {
    /**
     * 회원 신규가입때만 사용한다. enabled = true, deleted = false 이어야 하기때문
     * 만약 회원 업데이트시 사용한다면, 강제로 enabled = true, deleted = false 가 되기 때문에 사용하면 안된다.
     * @return
     */
    public Member toEntity() {
        return Member.builder()
                .mId(mId)
                .memberId(memberId)
                .password(password)
                .phone(phone)
                .bankCode(bankCode)
                .bankAccount(bankAccount)
                .bankAccountHolder(bankAccountHolder)
                .bankIdentifier(bankIdentifier)
                .depositBankName(depositBankName)
                .depositBankCode(depositBankCode)
                .depositBankAccount(depositBankAccount)
                .depositBankAccountPeriodFrom(depositBankAccountPeriodFrom)
                .depositBankAccountPeriodTo(depositBankAccountPeriodTo)
                .enabled(true) // 기본값 true 설정
                .deleted(false)
                .build();
    }
}
