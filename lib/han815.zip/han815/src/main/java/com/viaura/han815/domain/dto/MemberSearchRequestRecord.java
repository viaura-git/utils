package com.viaura.han815.domain.dto;

public record MemberSearchRequestRecord(
        String memberId,
        Boolean enabled,
        Boolean deleted
) {}
