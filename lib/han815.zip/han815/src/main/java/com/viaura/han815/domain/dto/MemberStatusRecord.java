package com.viaura.han815.domain.dto;

public record MemberStatusRecord(
        Boolean enabled,
        Boolean deleted
) {
}
