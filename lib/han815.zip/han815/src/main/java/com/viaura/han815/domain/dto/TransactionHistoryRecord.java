package com.viaura.han815.domain.dto;

import com.viaura.han815.domain.types.TransactionType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record TransactionHistoryRecord(

        Long tId,
        TransactionType type,
        String memberId,
        String memberName,
        Long amount,
        String withdrawalBankName,
        String withdrawalBankCode,
        String withdrawalBankAccount,
        String withdrawalBankAccountHolder,
        String withdrawalBankIdentifier,
        LocalDateTime withdrawalDate, //실제 출금일
        String withdrawalStatus, // 출금요청 상태
        String depositPaymentCompanyId,
        String depositPaymentId,
        String depositBankName,
        String depositBankCode,
        String depositBankAccount,
        LocalDateTime depositBankAccountPeriodFrom,
        LocalDateTime depositBankAccountPeriodTo,
        LocalDateTime depositDate,
        Long siteId,
        Long distId,
        BigDecimal distCommRate,
        BigDecimal distCommFee,
        BigDecimal hqCommRate,
        BigDecimal hqCommFee,
        BigDecimal balance,
        LocalDateTime regDate

) {}
