package com.viaura.han815.domain.dto;

import com.viaura.han815.domain.types.TransactionType;

import java.math.BigDecimal;

public record TransactionHourlySummaryRecord (

    Integer hour,
    String type,
    Long count,
    BigDecimal amount
){
    public TransactionType getTransactionType() {
        return TransactionType.valueOf(type);
    }
}