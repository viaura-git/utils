package com.viaura.han815.domain.dto;

import com.viaura.han815.domain.types.TransactionType;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Builder
@NoArgsConstructor @AllArgsConstructor
@Getter @Setter @ToString
public class TransactionSearchCondition {
        Long siteId;
        TransactionType transactionType;
        BigDecimal amount;
        String memberId;
        String withdrawalStatus;

        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        LocalDateTime from;

        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        LocalDateTime to;


}
