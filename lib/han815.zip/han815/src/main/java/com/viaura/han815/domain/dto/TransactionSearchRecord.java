package com.viaura.han815.domain.dto;

import com.viaura.han815.domain.types.TransactionType;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record TransactionSearchRecord(
        //공통조건
        TransactionType transactionType,
        String memberId,

        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        LocalDateTime from,
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        LocalDateTime to,

        //출금 리스트 전용 추가
        BigDecimal amount,
        String withdrawalStatus
) {

    public TransactionSearchCondition toEntity() {

        return TransactionSearchCondition.builder()
                .transactionType(transactionType)
                .memberId(memberId)
                .from(from)
                .to(to)
                .amount(amount)
                .withdrawalStatus(withdrawalStatus)

                .build();
    }
}
