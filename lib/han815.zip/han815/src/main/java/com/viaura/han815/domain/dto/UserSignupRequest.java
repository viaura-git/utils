package com.viaura.han815.domain.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;


public record UserSignupRequest (

        @NotBlank(message = "사용자명은 필수입니다.")
        @Size(min = 4, max = 20, message = "사용자명은 4자 이상 20자 이하여야 합니다.")
        String username,

        @NotBlank(message = "비밀번호는 필수입니다.")
        @Size(min = 8, message = "비밀번호는 최소 8자 이상이어야 합니다.")
        String password,

        @Email(message = "올바른 이메일 주소 형식이어야 합니다")
        @Pattern(
                regexp = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.(com|net|org|co\\.kr|kr)$",
                message = "허용되지 않은 이메일 도메인입니다."
        )
        @NotBlank(message = "이메일 주소는 필수입니다")
        String email,

        @NotBlank
        @Size(min = 10, max = 13)
        @Pattern(
                regexp = "^(01[016789])-?(\\d{3,4})-?(\\d{4})$",
                message = "전화번호 형식이 잘못되었습니다.\n 예: 010-1234-5678 또는 01012345678"
        )
        String phone,

        Long distId,
        Long siteId,

        List<String> roles // 예: USER, ADMIN
){}

