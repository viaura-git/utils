package com.viaura.han815.domain.dto;

public record WithdrawalPatchRecord(
        Long tId
) {
}
