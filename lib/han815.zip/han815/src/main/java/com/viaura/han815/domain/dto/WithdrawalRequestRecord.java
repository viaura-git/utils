package com.viaura.han815.domain.dto;

import com.viaura.han815.domain.entity.Dist;
import com.viaura.han815.domain.entity.Site;
import com.viaura.han815.domain.entity.TransactionHistory;
import com.viaura.han815.domain.types.TransactionType;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.math.RoundingMode;

public record WithdrawalRequestRecord(

        @NotBlank(message = "입금 출금 구분은 필수입니다")
        String type,

        @NotBlank(message = "입금자/출금자 아이디는 필수입니다")
        String memberId,

        String memberName,

        @NotNull(message = "출금금액은 필수입니다")
        @Min(value = 10000, message = "출금은 만원단위 입니다")
        Long amount,

        @NotNull(message = "출금계좌 은행명은 필수입니다")
        String withdrawalBankName,

        @NotNull(message = "출금계좌 은행코드는 필수입니다")
        String withdrawalBankCode,

        @NotNull(message = "출금계좌는 필수입니다")
        String withdrawalBankAccount,

        @NotNull(message = "출금계좌 예금주 명은 필수입니다")
        String withdrawalBankAccountHolder,

        @NotNull(message = "생년월일 또는 사업자번호는 필수입니다")
        String withdrawalBankIdentifier,

        Long siteId,

        Long distId,

        String withdrawalStatus

) {
    public TransactionHistory toEntity(Site site, Dist dist) {

        BigDecimal amount = BigDecimal.valueOf(this.amount());

        BigDecimal distRate = null; BigDecimal distFee = null;
        BigDecimal hqRate = null;   BigDecimal hqFee = null;

//        distRate = new BigDecimal(0);
//        distFee = new BigDecimal(0);
//        hqRate = new BigDecimal(0);
//        hqFee = new BigDecimal(0);

        if(this.type.equals(TransactionType.DEPOSIT.getValue())) {
            distRate = site.getCommRate(); // 예: 5.00 (%)
            distFee = amount.multiply(distRate)
                    .divide(BigDecimal.valueOf(100))
                    .setScale(0, RoundingMode.HALF_UP);

            hqRate = dist.getCommRate(); // 예: 10.00 (%)
            hqFee = amount.multiply(hqRate)
                    .divide(BigDecimal.valueOf(100))
                    .setScale(0, RoundingMode.HALF_UP);
        }

        return TransactionHistory.builder()
                .type(TransactionType.fromValue(this.type())
                        .orElseThrow(() -> new IllegalArgumentException("Invalid TransactionType: " + this.type())))
                .memberId(this.memberId())
                .memberName(this.memberName())
                .amount(this.amount())

                .withdrawalBankName(this.withdrawalBankName())
                .withdrawalBankCode(this.withdrawalBankCode())
                .withdrawalBankAccount(this.withdrawalBankAccount())
                .withdrawalBankAccountHolder(this.withdrawalBankAccountHolder())
                .withdrawalBankIdentifier(this.withdrawalBankIdentifier())

                //자체계산으로 세팅
                .distCommRate(distRate)
                .distCommFee(distFee)
                .hqCommRate(hqRate)
                .hqCommFee(hqFee)
                //받은 인자에서 추출
                .siteId(site.getSiteId())
                .distId(dist.getDistId())
                .withdrawalStatus(this.withdrawalStatus())

                .balance(amount.negate())

                .build();

    }


}
