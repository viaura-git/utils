package com.viaura.han815.domain.dto;

import java.time.LocalDateTime;

public record WithdrawalSearchRecord(
        String memberId,
        String withdrawalBankAccountHolder,
        String withdrawalStatus,
        LocalDateTime from,
        LocalDateTime to
) {
}
