package com.viaura.han815.domain.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;

import java.io.Serializable;

@Entity
@Table(name = "BANKS")
@Data
public class Bank implements Serializable {

    @Id
    @Column(name = "CODE", length = 10)
    private String code;

    @Column(name = "NAME", nullable = false, length = 50)
    private String name;

}
