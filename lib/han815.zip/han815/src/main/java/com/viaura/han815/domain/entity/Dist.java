package com.viaura.han815.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.Comment;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "DIST")
@Getter @Setter @ToString
public class Dist implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DIST_ID", nullable = false, updatable = false)
    private Long distId;

    @Column(name = "COMM_RATE", length = 7, nullable = false)
    @Comment("수수료")
    private BigDecimal commRate;

    @Column(name = "NAME", length = 50, nullable = false)
    private String name;

    @Column(name = "EMAIL", length = 50, nullable = false)
    private String email;

    @Column(name = "PHONE", length = 20, nullable = false)
    private String phone;

    @Column(name = "ENABLED", columnDefinition = "BOOLEAN DEFAULT TRUE",nullable = false)
    @Comment("총판 활성 여부")
    private boolean enabled = true;

    @CreatedDate
    @Column(name = "REG_DATE", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP",updatable = false)
    @ToString.Exclude
    private LocalDateTime regDate;

    @LastModifiedDate
    @Column(name = "UPD_DATE")
    @ToString.Exclude
    private LocalDateTime updDate;

    @Column(name = "DEL_DATE")
    @ToString.Exclude
    private LocalDateTime delDate;

    // 양방향 관계를 원할 경우
    @OneToMany(mappedBy = "dist")
    @ToString.Exclude
    @JsonIgnore //Member -> Site -> Dist -> Site 의 순환참조를 끊는다
    private List<Site> sites = new ArrayList<>();
}
