package com.viaura.han815.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.Comment;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "MEMBERS",
        uniqueConstraints = {
                @UniqueConstraint(name = "UNIQUE_USER_KEY", columnNames = {"MEMBER_ID", "DIST_ID", "SITE_ID"})
        }
)
@Getter @Setter @ToString(exclude = {"password", "regDate", "updDate", "delDate"})
@Builder @NoArgsConstructor @AllArgsConstructor
public class Member implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MID")
    @Comment("사용자 고유번호")
    private Long mId;

    @Column(name = "MEMBER_ID", length = 50, nullable = false)
    @Comment("사용자 ID")
    private String memberId;

//    @Column(name = "MEMBER_NAME", length = 50)
//    @Comment("사용자 이름")
//    private String managerName;

    @Column(name = "PASSWORD", length = 255, nullable = false)
    @Comment("비밀번호")
    private String password;

//    @Column(name = "EMAIL", length = 50, nullable = false)
//    @Comment("이메일 주소")
//    private String email;

    @Column(name = "PHONE", length = 20, nullable = false)
    @Comment("전화번호")
    private String phone;

    @Column(name = "BANK_NAME", length = 50, nullable = false)
    private String bankName;

    @Column(name = "BANK_CODE", length = 10)
    private String bankCode;

    @Column(name = "BANK_ACCOUNT", length = 100, nullable = false)
    private String bankAccount;

    @Column(name = "BANK_ACCOUNT_HOLDER", length = 50, nullable = false)
    private String bankAccountHolder;

    @Column(name = "BANK_IDENTIFIER", length = 10, nullable = false)
    @Size(min = 6, max = 10, message = "개인은 생년월일 YYMMDD 6자리, 사업자는 사업자번호 10자리입니다")
    private String bankIdentifier;

    @Column(name = "DEPOSIT_BANK_NAME", length = 100)
    private String depositBankName;

    @Column(name = "DEPOSIT_BANK_CODE", length = 10)
    private String depositBankCode;

    @Column(name = "DEPOSIT_BANK_ACCOUNT", length = 100)
    private String depositBankAccount;

    @Column(name = "DEPOSIT_BANK_ACCOUNT_PERIOD_FROM")
    private LocalDateTime depositBankAccountPeriodFrom;

    @Column(name = "DEPOSIT_BANK_ACCOUNT_PERIOD_TO")
    private LocalDateTime depositBankAccountPeriodTo;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "SITE_ID", referencedColumnName = "SITE_ID")
    @Comment("가맹점")
    private Site site;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "DIST_ID", referencedColumnName = "DIST_ID")
    @Comment("총판")
    @JsonIgnore //순환참조를 끊는다
    private Dist dist;

    @Column(name = "ENABLED", columnDefinition = "BOOLEAN DEFAULT TRUE", nullable = false)
    @Comment("활성 여부")
    private boolean enabled;

    @Column(name = "DELETED", columnDefinition = "BOOLEAN DEFAULT FALSE", nullable = false)
    @Comment("삭제 여부")
    private boolean deleted;

//    @Comment("사용자 권한")
//    private String roels = "ROLE_USER";

    @CreatedDate
    @Column(name = "REG_DATE", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP", nullable = false, updatable = false) //insertable = false 하면 아무리 JPA라도 insert 하지 않는다
    @Comment("생성일")
    private LocalDateTime regDate;

    @LastModifiedDate
    @Column(name = "UPD_DATE")
    @Comment("마지막 변경일")
    private LocalDateTime updDate;

    @Column(name = "DEL_DATE")
    @Comment("삭제일")
    private LocalDateTime delDate;

//    @Column(name = "PASSWORD_CHANGED_DATE")
//    @Comment("비밀번호 마지막 변경일")
//    private LocalDateTime passwordChangedDate;

//    public boolean isFirstLogin(){
//        return this.passwordChangedDate == null;
//    }
}
