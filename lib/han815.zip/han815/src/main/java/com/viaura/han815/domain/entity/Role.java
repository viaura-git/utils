package com.viaura.han815.domain.entity;

import com.viaura.han815.domain.types.RoleType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.ToString;

import java.io.Serializable;

@Entity
@Table(name = "ROLES")
@Getter @ToString
public class Role implements Serializable {

    @Id
    @Enumerated(EnumType.STRING)
    @Column(name = "ROLE_NAME")
    private RoleType roleName; // 예: ROLE_USER, ROLE_ADMIN, ROLE_SITE, ROLE_DIST
}
