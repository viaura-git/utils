package com.viaura.han815.domain.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.Comment;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "SITE")
@Getter @Setter @ToString
public class Site implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SITE_ID")
    private Long siteId;

    @Column(name = "COMM_RATE", length = 7, nullable = false)
    @Comment("수수료")
    private BigDecimal commRate;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "DIST_ID", referencedColumnName = "DIST_ID")
    @Comment("총판 ID")
    private Dist dist;

    @Column(name = "EMAIL", length = 50, nullable = false)
    private String email;

    @Column(name = "NAME", length = 50, nullable = false)
    private String name;

    @Column(name = "PHONE", length = 20, nullable = false)
    private String phone;

    @Column(name = "ENABLED", columnDefinition = "BOOLEAN DEFAULT TRUE",nullable = false)
    @Comment("가맹점 활성 여부")
    private boolean enabled = true;

    @CreatedDate
    @Column(name = "REG_DATE", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP", updatable = false)
    @ToString.Exclude
    private LocalDateTime regDate;

    @LastModifiedDate
    @Column(name = "UPD_DATE")
    @ToString.Exclude
    private LocalDateTime updDate;

    @Column(name = "DEL_DATE")
    @ToString.Exclude
    private LocalDateTime delDate;

}
