package com.viaura.han815.domain.entity;

import com.viaura.han815.domain.types.TransactionType;
import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.Comment;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "TRANSACTION_HISTORY")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransactionHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "TID", nullable = false, updatable = false)
    private Long tId; // 고유번호

    @Enumerated(EnumType.STRING)
    @Column(name = "TYPE", nullable = false)
    private TransactionType type;

    @Column(name = "MEMBER_ID", nullable = false, length = 50)
    private String memberId; // 입출금 ID

    @Column(name = "MEMBER_NAME", length = 50)
    private String memberName; // 입출금자 이름

    @Column(name = "AMOUNT", nullable = false)
    private Long amount; // 충전금액, 출금금액

    @Column(name = "WITHDRAWAL_BANK_NAME", length = 50)
    private String withdrawalBankName;

    @Column(name = "WITHDRAWAL_BANK_CODE", length = 10)
    private String withdrawalBankCode;

    @Column(name = "WITHDRAWAL_BANK_ACCOUNT", length = 100)
    private String withdrawalBankAccount;

    @Column(name = "WITHDRAWAL_BANK_ACCOUNT_HOLDER", length = 50)
    private String withdrawalBankAccountHolder;

    @Column(name = "WITHDRAWAL_DATE")
    private LocalDateTime withdrawalDate;

    @Column(name = "WITHDRAWAL_BANK_IDENTIFIER", length = 10)
    private String withdrawalBankIdentifier;

    @Column(name = "WITHDRAWAL_STATUS", length = 20)
    private String withdrawalStatus;

    @Column(name = "DEPOSIT_PAYMENT_COMPANY_ID", length = 50)
    private String depositPaymentCompanyId; // PAYMENT 회사 고유번호

    @Column(name = "DEPOSIT_PAYMENT_ID", length = 50)
    private String depositPaymentId; // PAYMENT 고유번호

    @Column(name = "DEPOSIT_BANK_NAME", length = 100)
    private String depositBankName;

    @Column(name = "DEPOSIT_BANK_CODE", length = 10)
    private String depositBankCode;

    @Column(name = "DEPOSIT_BANK_ACCOUNT", length = 100)
    private String depositBankAccount;

    @Column(name = "DEPOSIT_BANK_ACCOUNT_PERIOD_FROM")
    private LocalDateTime depositBankAccountPeriodFrom;

    @Column(name = "DEPOSIT_BANK_ACCOUNT_PERIOD_TO")
    private LocalDateTime depositBankAccountPeriodTo;

    @Column(name = "DEPOSIT_DATE")
    private LocalDateTime depositDate;

    @Column(name = "SITE_ID", nullable = false)
    private Long siteId; // 가맹점 ID

    @Column(name = "DIST_ID", nullable = false)
    private Long distId; // 가맹점 ID

    @Column(name = "DIST_COMM_RATE")
    private BigDecimal distCommRate;

    @Column(name = "DIST_COMM_FEE")
    private BigDecimal distCommFee;

    @Column(name = "HQ_COMM_RATE")
    private BigDecimal hqCommRate;

    @Column(name = "HQ_COMM_FEE")
    private BigDecimal hqCommFee;

    @Column(name = "BALANCE")
    @Comment("입금에 대한 수수료 제외 가맹점 몫의 잔여금액")
    private BigDecimal balance;

    @Column(name = "REG_DATE", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private LocalDateTime regDate; // 송신받은 날짜

    @PrePersist
    protected void onCreate() {
        if (regDate == null) {
            regDate = LocalDateTime.now();
        }
    }

    @PreUpdate
    protected void onUpdate() {
        if (withdrawalDate == null) {
            withdrawalDate = LocalDateTime.now();
        }
    }
}
