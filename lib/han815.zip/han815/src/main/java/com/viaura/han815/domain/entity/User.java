package com.viaura.han815.domain.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.Comment;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "USERS",
        uniqueConstraints = {
                @UniqueConstraint(name = "UNIQUE_USER_KEY", columnNames = {"USER_ID", "DIST_ID", "SITE_ID"})
        }
)
@Getter @Setter @ToString(exclude = {"password", "phone", "regDate", "updDate", "passwordChangedDate"})
@Builder @NoArgsConstructor @AllArgsConstructor
public class User implements Serializable {

    @Serial
    private static final long serialVersionUID = 8644532104784328711L;


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Comment("사용자 고유번호")
    @Column(name = "UID")
    private Long uId;

    @Column(name = "USER_ID", length = 50, nullable = false)
    @Comment("사용자 ID")
    private String userId;

    @Column(name = "USER_NAME", length = 50)
    @Comment("사용자 이름")
    private String userName;

    @Column(name = "PASSWORD", length = 255, nullable = false)
    @Comment("비밀번호")
    private String password;

    @Column(name = "EMAIL", length = 50, nullable = false)
    @Comment("이메일 주소")
    private String email;

    @Column(name = "PHONE", length = 20, nullable = false)
    @Comment("전화번호")
    private String phone;

    @Column(name = "BANK_NAME", length = 50, nullable = false)
    private String bankName;

    @Column(name = "BANK_CODE", length = 10)
    private String bankCode;

    @Column(name = "BANK_ACCOUNT", length = 100, nullable = false)
    private String bankAccount;

    @Column(name = "BANK_ACCOUNT_HOLDER", length = 100, nullable = false)
    private String bankAccountHolder;

    @Column(name = "BANK_IDENTIFIER", length = 50, nullable = false)
    private String bankIdentifier;

    /**
     * MEMBERS 와 비슷한 구조로 구성, USERS에서는 필요없다
    @Column(name = "DEPOSIT_BANK_NAME", length = 100)
    private String depositBankName;

    @Column(name = "DEPOSIT_BANK_CODE", length = 10)
    private String depositBankCode;

    @Column(name = "DEPOSIT_BANK_ACCOUNT", length = 100)
    private String depositBankAccount;

    @Column(name = "DEPOSIT_BANK_ACCOUNT_PERIOD_FROM")
    private LocalDateTime depositBankAccountPeriodFrom;

    @Column(name = "DEPOSIT_BANK_ACCOUNT_PERIOD_TO")
    private LocalDateTime depositBankAccountPeriodTo;
     */

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "SITE_ID", referencedColumnName = "SITE_ID")
    @Comment("가맹점")
    private Site site;

    @Column(name = "ENABLED", nullable = false)
    @Comment("활성유저 여부")
    private boolean enabled;

//    @Column(name = "DELETED", nullable = false)
//    @Comment("활성유저 여부")
//    private boolean deleted;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "user_roles",
            joinColumns = @JoinColumn(name = "USER_UNIQUE_ID"),
            inverseJoinColumns = @JoinColumn(name = "ROLE_NAME")
    )
    @Comment("사용자 권한")
    private Set<Role> roles = new HashSet<>();

    @CreatedDate
    @Column(name = "REG_DATE", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP", nullable = false, updatable = false) //insertable = false 하면 아무리 JPA라도 insert 하지 않는다
    @Comment("생성일")
    private LocalDateTime regDate;

    @LastModifiedDate
    @Column(name = "UPD_DATE")
    @Comment("마지막 변경일")
    private LocalDateTime updDate;

//    @Column(name = "DEL_DATE")
//    @Comment("삭제일")
//    private LocalDateTime delDate;

    @Column(name = "PASSWORD_CHANGED_DATE")
    @Comment("비밀번호 마지막 변경일")
    private LocalDateTime passwordChangedDate;

    public boolean isFirstLogin(){
        return this.passwordChangedDate == null;
    }
}
