package com.viaura.han815.domain.record;

import java.math.BigDecimal;

public record DepositNotification(
        String message,
        Long amount
) {}
