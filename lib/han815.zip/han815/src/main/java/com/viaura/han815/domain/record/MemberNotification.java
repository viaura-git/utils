package com.viaura.han815.domain.record;

public record MemberNotification(
        String memberId,
        String message
) {
}
