package com.viaura.han815.domain.record;

import java.io.Serializable;
import java.util.Set;

public record SessionUser(String userId, String userName, Set<String> roles) implements Serializable {
    private static final long serialVersionUID = 1L;
}

