package com.viaura.han815.domain.types;

import java.util.Arrays;
import java.util.Optional;

public enum BankType {
        KDB("002", "KDB산업은행"),
        IBK("003", "IBK기업은행"),
        KB("004", "KB국민은행"),
        KEB("005", "KEB하나은행"),
        SUHYUP("007", "수협은행"),
        NH("011", "NH농협은행"),
        WOORI("020", "우리은행"),
        SC("023", "SC제일은행"),
        CITI("027", "한국씨티은행"),
        DGB("031", "DGB대구은행"),
        BNK("032", "BNK부산은행"),
        KWANGJU("034", "광주은행"),
        JEJU("035", "제주은행"),
        JEONBUK("037", "전북은행"),
        KYONGNAM("039", "경남은행"),
        MG("045", "MG새마을금고"),
        CREDIT("048", "신협"),
        MUTUAL("050", "상호저축은행"),
        FORREST("064", "산림조합중앙회"),
        KOREAPOST("071", "우체국"),
        HANA("081", "하나은행"),
        SHINHAN("088", "신한은행"),
        KBANK("089", "케이뱅크"),
        KAKAO("090", "카카오뱅크"),
        TOSS("092", "토스뱅크");

    private final String code;
    private final String name;

    BankType(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    // 코드로 Enum 찾기
    public static Optional<BankType> fromCode(String code) {
        return Arrays.stream(values())
                .filter(b -> b.code.equals(code))
                .findFirst();
    }

    // 이름으로 Enum 찾기
    public static Optional<BankType> fromName(String name) {
        return Arrays.stream(values())
                .filter(b -> b.name.equals(name))
                .findFirst();
    }
}
