package com.viaura.han815.domain.types;

import java.util.Arrays;
import java.util.Optional;

public enum RoleType {
    ROLE_ADMIN("본사관리자"),
    ROLE_DIST("총판관리지"),
    ROLE_SITE("가맹점관리자"),
    ROLE_USER("가맹점고객");

    private String roleName;

    RoleType(String roleName) {
        this.roleName = roleName;
    }

}

