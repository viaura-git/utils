package com.viaura.han815.domain.types;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Arrays;
import java.util.Optional;

@AllArgsConstructor
@Getter
public enum TransactionType {
    DEPOSIT("DEPOSIT"), WITHDRAWAL("WITHDRAWAL");

    private String value;

    // 코드로 Enum 찾기
    public static Optional<TransactionType> fromValue(String value) {
        return Arrays.stream(values())
                .filter(b -> b.value.equals(value))
                .findFirst();
    }
}
