package com.viaura.han815.event;

import com.viaura.han815.domain.record.DepositNotification;
import com.viaura.han815.domain.record.MemberNotification;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class EventPublisher {

    private final SimpMessagingTemplate messagingTemplate;

    public void publishDepositHistoryEvent(Long siteId, Long amount) {
        messagingTemplate.convertAndSend("/topic/doposit/"+siteId,
                new DepositNotification("입금이 발생했습니다", amount)  );
    }

    public void publishMemberFindEvent(Long siteId, String memberId, String message) {
        log.debug("-------> publishMemberFindEvent publishing start ");
        messagingTemplate.convertAndSend("/topic/member/"+siteId,
                new MemberNotification(memberId, message));
    }
}
