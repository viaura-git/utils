package com.viaura.han815.repository;

import com.viaura.han815.domain.dto.MemberSearchRequestRecord;
import com.viaura.han815.domain.entity.Member;
import com.viaura.han815.domain.entity.Site;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface MemberRepository extends JpaRepository<Member, Long> {

    boolean existsBySiteAndMemberId(Site site, String memberId);



    @Modifying
    @Transactional
    @Query("UPDATE Member m SET " +
            "m.depositBankCode = :depositBankCode, " +
            "m.depositBankAccount = :depositBankAccount, " +
            "m.depositBankName = :depositBankName " +
            "WHERE m.site = :site AND m.mId = :id AND m.deleted = false")
    int updateDepositAccount(@Param("site") Site site, @Param("id") Long id,
                                 @Param("depositBankCode") String depositBankCode,
                                 @Param("depositBankName") String depositBankName,
                                 @Param("depositBankAccount") String depositBankAccount);


    Page<Member> findBySite(Site site, Pageable pageable);

    Member findBySiteAndMemberId(Site site, String memberId);

    Page<Member> findBySiteAndMemberIdContainingIgnoreCase(Site site, String s, Pageable pageable);

    Page<Member> findBySiteAndEnabled(Site site, Boolean enabled, Pageable pageable);

    Page<Member> findBySiteAndMemberIdContainingIgnoreCaseAndEnabled(Site site, String s, Boolean enabled, Pageable pageable);

    Page<Member> findBySiteAndDeleted(Site site, Boolean deleted, Pageable pageable);

    Page<Member> findBySiteAndMemberIdContainingIgnoreCaseAndDeleted(Site site, String s, Boolean deleted, Pageable pageable);

    @Query("""
    SELECT m
      FROM Member m
     WHERE m.site = :site
       AND (m.enabled = :enabled OR m.deleted = :deleted)
""")
    Page<Member> findBySiteAndEnabledOrDeleted(Site site, Boolean enabled, Boolean deleted, Pageable pageable);


    @Query("""
    SELECT m
      FROM Member m
     WHERE m.site = :site
       AND (:memberId IS NULL OR LOWER(m.memberId) LIKE LOWER(CONCAT('%', :memberId, '%')))
       AND (m.enabled = :enabled OR m.deleted = :deleted)
""")
    Page<Member> findBySiteAndMemberIdContainingIgnoreCaseAndEnabledOrDeleted(Site site, String memberId, Boolean enabled, Boolean deleted, Pageable pageable);

}
