package com.viaura.han815.repository;

import com.viaura.han815.domain.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;


public interface RoleRepository extends JpaRepository<Role, String> {
}
