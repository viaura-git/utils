package com.viaura.han815.repository;

import com.viaura.han815.domain.dto.TransactionHistoryRecord;
import com.viaura.han815.domain.dto.TransactionHourlySummaryRecord;
import com.viaura.han815.domain.dto.TransactionSearchRecord;
import com.viaura.han815.domain.entity.TransactionHistory;
import com.viaura.han815.domain.types.TransactionType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.parameters.P;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface TransactionHistoryRepository extends JpaRepository<TransactionHistory, Long> {

    //JPQL 방식
    /**
     * JPQL 예제 record와 JPA / JPQL 을 사용하는 것은 검색조건에서는 제약이 너무 많아 POJO 와 native SQL 로 변경하려했으나
     * 값이 없으면 조건이 사라지는 기능이 존재하지 않아 쓸 수가 없다. MyBatis 가 제일 낫네
     * record는 불변이기에 가져온 값이 null 이면 채워야 하는 경우 setter가 없어 너무 불편하다. record는 쿼리 결과 리턴값을 사용함이 바람직하다
     * **/
    @Query("""
    SELECT d FROM TransactionHistory d
    WHERE (:siteId IS NULL OR d.siteId = :siteId)
      AND (:transactionType IS NULL OR d.type = :transactionType)
      AND (:memberId IS NULL OR d.memberId LIKE %:memberId%)
      AND (:amount IS NULL OR d.amount = :amount)
      AND (:withdrawalStatus IS NULL OR d.withdrawalStatus = :withdrawalStatus)
      AND (:from IS NULL OR d.regDate >= :from)
      AND (:to IS NULL OR d.regDate <= :to)
    ORDER BY d.regDate DESC
    """)
    /** native Query 방식은 이렇게 쓴다. 앞으로는 DB native 함수를 쓰기위해 native Query를 사용할 것임
     * 하지만 JPQL 예제를 위해 남겨둠
     * method 명이 search로 시작하면 native query를
     * find로 시작하면 JPQL 이나 JPA 기본 메소드 사용함을 규칙으로 정한다
     * find로 시작하면 JPQL 이나 JPA 기본 메소드 사용함을 규칙으로 정한다
     * 제약은 DTO에 값이 없으면 조건이 사라져야 하는데 SQL이 고정이라 반드시 값을 채워야 한다는게 문제. 역시 MyBatis가 최고
     @Query( value = "SELECT * " +
                       "FROM TRANSACTION_HISTORY " +
                      "WHERE SITE_ID = :siteID " +
                      "  AND USER_NAME LIKE %:userName% " +
                      "  AND PAYMENT_COMPANY_ID = :paymentCompanyId " +
                      "  AND REG_DATE >= :from "+
                      "  AND REG_DATE < :to " +
                      "ORDER BY REG_DATE DESC", nativeQuery = true)
     **/
    Page<TransactionHistoryRecord> findTransactionsWithCondition(
            @Param("siteId") Long siteId,
            @Param("transactionType") TransactionType transactionType,
            @Param("memberId") String memberId,
            @Param("amount") BigDecimal amount,
            @Param("withdrawalStatus") String withdrawalStatus,
            @Param("from") LocalDateTime from,
            @Param("to") LocalDateTime to,
            Pageable pageable
    );

    //native query 사용방식
    //it is shorter , there is no need to use 'AND timestamp < CURDATE() + INTERVAL 1 DAY'
    //because CURDATE() always return current day
    @Query(value = """
    SELECT 
        HOUR(REG_DATE) AS hour,
        TYPE AS type,
        COUNT(amount) AS count,
        SUM(amount) AS amount
    FROM TRANSACTION_HISTORY
    WHERE SITE_ID = :siteId
      AND REG_DATE >= CURDATE()
      AND REG_DATE < CURDATE() + INTERVAL 1 DAY
    GROUP BY HOUR(REG_DATE), TYPE
    ORDER BY hour
""", nativeQuery = true)
    List<TransactionHourlySummaryRecord> findTodayHourlyTransactionsGroupedByType(@Param("siteId") Long siteId);



    @Query("""
    SELECT SUM(d.amount)
     FROM TransactionHistory d
    WHERE (:siteId IS NULL OR d.siteId = :siteId)
      AND (:transactionType IS NULL OR d.type = :transactionType)
      AND (:memberId IS NULL OR d.memberId LIKE %:memberId%)
      AND (:from IS NULL OR d.regDate >= :from)
      AND (:to IS NULL OR d.regDate <= :to)
    """)
    Long sumAmountsWithCondition(@Param("siteId") Long siteId,
                              @Param("transactionType")  TransactionType transactionType,
                              @Param("memberId") String memberId,
                              @Param("from") LocalDateTime from,
                              @Param("to") LocalDateTime to);

    @Query("""
     SELECT
         SUM(t.balance) AS total_balance
       FROM TransactionHistory t
      WHERE t.siteId = :siteId
        AND (t.withdrawalStatus IS NULL OR t.withdrawalStatus = 'CONFIRMED')
    """)
    Long sumBalanceBySite(Long siteId);

    @Query("""
    SELECT t
      FROM TransactionHistory t
     WHERE (:from IS NULL OR t.regDate >= :from)
       AND (:to IS NULL OR t.regDate <= :to)
""")
    Page<TransactionHistoryRecord> findAllByHq(
            @Param("from") LocalDateTime from,
            @Param("to") LocalDateTime to,
            Pageable pageable
    );

}

