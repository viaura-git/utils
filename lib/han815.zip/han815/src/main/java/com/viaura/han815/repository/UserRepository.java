package com.viaura.han815.repository;

import com.viaura.han815.domain.entity.Site;
import com.viaura.han815.domain.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;


import java.util.Optional;

public interface UserRepository extends JpaRepository<User, String> {

    Optional<User> findByUserId(String userId);
    Optional<Object> findWithDistByUserId(String userId);


    Optional<User> findBySiteAndUserIdContaining(Site site, String userId);
}
