package com.viaura.han815.service;

import com.viaura.han815.domain.dto.MemberRegisterRecord;
import com.viaura.han815.domain.entity.Dist;
import com.viaura.han815.domain.entity.Member;
import com.viaura.han815.domain.entity.Site;
import com.viaura.han815.domain.types.BankType;
import com.viaura.han815.repository.MemberRepository;
import com.viaura.han815.service.user.CustomUserDetails;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class MemberService {

    private final MemberRepository memberRepository;

    public Member save(MemberRegisterRecord record, CustomUserDetails user) {
        Site site = user.getUser().getSite();
        Dist dist = site.getDist();

        Member newMember = record.toEntity();
        newMember.setSite(site);
        newMember.setDist(dist);

        BankType bank = BankType.fromCode(record.bankCode()).orElseThrow(() -> new IllegalArgumentException("BankCode에 맞는 은행이름이 없습니다"));
        log.debug("bank : {}", bank);
        newMember.setBankName(bank.getName());

        log.debug("newMember : {}", newMember);

        return memberRepository.save(newMember);
    }

    public boolean existsBySiteAndMemberId(String memberId, Authentication auth) {
        CustomUserDetails user = (CustomUserDetails) auth.getPrincipal();
        Site site = user.getUser().getSite();

        log.debug("----> memberId : {}", memberId);
        log.debug("----> site : {}", site);

        return memberRepository.existsBySiteAndMemberId(site, memberId);
    }
}
