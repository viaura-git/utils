package com.viaura.han815.service;

import com.viaura.han815.domain.entity.Site;
import com.viaura.han815.repository.SiteRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class SiteService {

    private final SiteRepository siteRepository;

    public List<Long> findAllSiteIds(boolean enabled) {
        return siteRepository.findAllByEnabled(enabled).stream()
                .map(Site::getSiteId)
                .collect(Collectors.toList());
    }

}
