package com.viaura.han815.service;


import com.viaura.han815.domain.dto.TransactionHistoryRecord;
import com.viaura.han815.domain.dto.TransactionHourlySummaryRecord;
import com.viaura.han815.domain.dto.TransactionSearchCondition;
import com.viaura.han815.domain.dto.TransactionSearchRecord;
import com.viaura.han815.domain.entity.TransactionHistory;
import com.viaura.han815.domain.types.TransactionType;
import com.viaura.han815.event.EventPublisher;
import com.viaura.han815.repository.TransactionHistoryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class TransactionHistoryService {

    private final TransactionHistoryRepository transactionHistoryRepository;
    private final EventPublisher eventPublisher;

    @Transactional
    public TransactionHistory save(TransactionHistory dto) {

        TransactionHistory deposit = transactionHistoryRepository.save(dto);
        eventPublisher.publishDepositHistoryEvent(dto.getSiteId(), dto.getAmount());
        return deposit;
    }

    public List<TransactionHistory> saveAll(List<TransactionHistory> deposits) {
        return transactionHistoryRepository.saveAll(deposits);
    }

    public Page<TransactionHistoryRecord> findTransactionsWithCondition(TransactionSearchCondition dto, Pageable pageable) {
        Page<TransactionHistoryRecord> result = transactionHistoryRepository.findTransactionsWithCondition(
                dto.getSiteId(),
                dto.getTransactionType(),  // enum 그대로 전달
                dto.getMemberId(),
                dto.getAmount(),
                dto.getWithdrawalStatus(),
                dto.getFrom(),
                dto.getTo(),
                pageable
        );
        log.debug("result: {}", result);
        return result;
    }

    public List<TransactionHourlySummaryRecord> findTodayHourlyTransactionsGroupedByType(Long siteId) {

        /**
         *  SELECT HOUR(reg_date), SUM(amount)
         *     FROM TRANSACTION
         *     WHERE reg_date >= CURDATE() - INTERVAL 7 DAY  <-- 이부분 BadJPQL 에러
         *       AND reg_date < CURDATE() + INTERVAL 1 DAY   <-- 이부분 BadJPQL 에러
         *     GROUP BY HOUR(reg_date)
         *     ORDER BY HOUR(reg_date)
         */
        //JPQL 에서 native query 로 변경. from, to 필요없음
//        LocalDateTime from = LocalDate.now().atStartOfDay(); // 오늘 00:00
//        LocalDateTime to    = from.plusDays(1);              // 내일 00:00

        return transactionHistoryRepository.findTodayHourlyTransactionsGroupedByType(siteId);
    }

    public Long sumAmountsWithCondition(TransactionSearchCondition dto) {
        Long sum = transactionHistoryRepository.sumAmountsWithCondition(dto.getSiteId(), dto.getTransactionType(),
                dto.getMemberId(), dto.getFrom(), dto.getTo());

        if(sum == null) sum = 0l;

        log.debug("--------> sum : {}", sum);
        return sum;
    }


    /**
    public List<DepositHistoryRecord> findTop10ByOrderByRegDateDesc() {
        return depositHistoryRepository.findTop10ByOrderByRegDateDesc();
    }
     **/
}
