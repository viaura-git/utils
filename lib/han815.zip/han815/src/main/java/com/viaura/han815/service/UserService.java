package com.viaura.han815.service;

import com.viaura.han815.domain.dto.UserSignupRequest;
import com.viaura.han815.domain.entity.Role;
import com.viaura.han815.domain.entity.Site;
import com.viaura.han815.domain.types.RoleType;
import com.viaura.han815.repository.RoleRepository;
import com.viaura.han815.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.viaura.han815.domain.entity.User;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class UserService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    public void signup(UserSignupRequest request) {

        //UserId 중복검사
        if (userRepository.existsById(request.username())) {
            throw new RuntimeException("이미 존재하는 사용자입니다.");
        }

        // Role (List) 가 정의된 ROLE이고 DB에 있는지 검사
        Set<Role> roles = request.roles().stream()
                .map(roleName -> {
                    //1. 정의된 Role enumType 검사
                    RoleType roleType;
                    try {
                        roleType = RoleType.valueOf(roleName.toUpperCase());
                    } catch (IllegalArgumentException e) {
                        throw new IllegalArgumentException("존재하지 않는 권한입니다: " + roleName);
                    }
                    //2. DataBase에 권한이 기록되어 있는지 검사
                    return roleRepository.findById(roleName)
                            .orElseThrow(() -> new IllegalArgumentException("DB에 권한정보가 없습니다: " + roleName));
                })
                .collect(Collectors.toSet());

        // User 객체생성
        User user = User.builder()
                .userName(request.username())
                .password(passwordEncoder.encode(request.password()))
                .roles(roles)
                .enabled(true)
                .passwordChangedDate(null)
                .build();

        userRepository.save(user);
    }

    @Transactional
    public void updatePassword(String userId, String newPassword) {
        User user = userRepository.findByUserId(userId).orElseThrow(() -> new UsernameNotFoundException("사용자를 찾을 수 없습니다: " + userId));
        user.setPassword(passwordEncoder.encode(newPassword));
        user.setPasswordChangedDate(LocalDateTime.now());
        userRepository.save(user);
    }

    public Optional<User> findBySiteAndUserId(Site site, String userId) {
        return userRepository.findBySiteAndUserIdContaining(site, userId);
    }

}
