package com.viaura.han815.service.user;

import com.viaura.han815.domain.entity.Dist;
import lombok.ToString;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import com.viaura.han815.domain.entity.User;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.stream.Collectors;

@ToString
public class CustomUserDetails implements UserDetails {

    private final User user;

    public CustomUserDetails(User user) {
        this.user = user;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return user.getRoles().stream()
                .map(role -> new SimpleGrantedAuthority(role.getRoleName().name()))
                .collect(Collectors.toSet());
    }

    @Override //통상 말하는 password
    public String getPassword() {
        return user.getPassword();
    }

    @Override //통상 말하는 user name
    public String getUsername() {
        return user.getUserName();
    }

    //통상 말하는 user id
    public String getUserId() {
        return user.getUserId();
    }

    public Long getDistId() {
        return user.getSite().getDist().getDistId();
    }

    public Long getSiteId() {
        return user.getSite().getSiteId();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return user.isEnabled();
    }

    public boolean isFirstLogin() {
        return user.isFirstLogin();
    }

    public User getUser() {
        return this.user; // 원본 엔티티가 필요할 경우 사용
    }
}

