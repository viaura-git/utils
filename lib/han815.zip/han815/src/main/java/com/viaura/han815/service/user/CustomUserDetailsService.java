package com.viaura.han815.service.user;

import com.viaura.han815.domain.entity.User;
import com.viaura.han815.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CustomUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;

    public CustomUserDetailsService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    //이름은 맞지 않지만, 한국정서에 맞게 수정
    //loadUserByUsername() --> 원래 loadUserByUserId() 가 맞다
    @Override
    public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
//        User user = (User) userRepository.findByUserId(userId)
        User user = (User) userRepository.findWithDistByUserId(userId)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        log.info("Loading UserDetails for user: " + user.toString());
        log.info("Loading UserDetails for user: " + user.getRoles().toString());

        return new CustomUserDetails(user);
    }
}

