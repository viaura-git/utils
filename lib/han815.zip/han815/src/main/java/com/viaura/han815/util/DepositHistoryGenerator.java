package com.viaura.han815.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.viaura.han815.domain.entity.TransactionHistory;
import com.viaura.han815.domain.types.BankType;
import com.viaura.han815.domain.types.TransactionType;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class DepositHistoryGenerator {

    private static final List<String> PAYMENT_COMPANIES = List.of("PG0001", "PG0002", "PG0003");
    private static final List<String> STAUS = List.of("NEW", "CONFIRMED");

    private static final List<Integer> SITE_IDS = List.of(1001, 1002, 1003, 1004);
    private static final LocalDateTime PERIOD_FROM = LocalDate.of(2025,07,18).atStartOfDay();
    private static final LocalDateTime PERIOD_TO = LocalDate.of(2026,07,16).atTime(LocalTime.MAX);


    public static void main(String[] args) {
        List<TransactionHistory> data = generate(50);
        saveToJsonFile(data, "deposit_history_minus_50.json");
    }

    public static List<TransactionHistory> generate(int count) {
        BankType[] banks = BankType.values();
        Random random = new Random();
        List<TransactionHistory> list = new ArrayList<>();
        LocalDateTime now = LocalDateTime.now();

        List<String> memberPool = IntStream.rangeClosed(1, 10)
                .mapToObj(i -> String.format("member%03d", i))
                .collect(Collectors.toList());

        Map<Long, Long> distIdMap = new HashMap<>();
        distIdMap.put(1001L, 101L);
        distIdMap.put(1002L, 101L);
        distIdMap.put(1003L, 102L);
        distIdMap.put(1004L, 102L);


        for (int i = 0; i < count; i++) {
            String memberId = memberPool.get(random.nextInt(memberPool.size()));

            // 숫자 부분만 추출 (예: member023 → 023)
            String numberPart = memberId.replaceAll("\\D+", ""); // 숫자만 남김
            String memberName = "홍길동" + numberPart;

            String depositPaymentCompanyId = PAYMENT_COMPANIES.get(random.nextInt(PAYMENT_COMPANIES.size()));
            String depositPaymentId = depositPaymentCompanyId + "-PID-" + String.format("%06d", random.nextInt(1_000_000));

            Long amount = (random.nextInt(100) + 1L) * 10_000L;

            BankType randomBank = banks[new Random().nextInt(banks.length)];

            String bankName = randomBank.getName();
            String bankCode = randomBank.getCode();
            String bankAccount = bankCode + "-" + String.format("%06d", random.nextInt(1_000_000)) + "-001";

            Long siteId = Long.valueOf(SITE_IDS.get(random.nextInt(SITE_IDS.size())));
            Long distId = distIdMap.get(siteId);
//            String status = STAUS.get(random.nextInt(STAUS.size()));
//            LocalDateTime regDate = now.plusMinutes(i * 5L);
            LocalDateTime regDate = now.minusMinutes(i * 5L);
            LocalDateTime depositDate = now.minusMinutes(1L);

            TransactionHistory d = new TransactionHistory();
            d.setType(TransactionType.DEPOSIT);
            d.setMemberId(memberId);
            d.setMemberName(memberName);
            d.setDepositPaymentCompanyId(depositPaymentCompanyId);
            d.setDepositPaymentId(depositPaymentId);
            d.setAmount(amount);
            d.setDepositBankName(bankName);
            d.setDepositBankCode(bankCode);
            d.setDepositBankAccount(bankAccount);
            d.setDepositBankAccountPeriodFrom(PERIOD_FROM);
            d.setDepositBankAccountPeriodTo(PERIOD_TO);
            d.setSiteId(siteId);
            d.setDistId(distId);
//            d.setWithdrawalStatus(status);
            d.setDepositDate(regDate);
            d.setDepositDate(depositDate);
            d.setRegDate(regDate);

            list.add(d);
        }

        return list;
    }

    public static void saveToJsonFile(List<TransactionHistory> list, String fileName) {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

        try {
            mapper.writeValue(new File(fileName), list);
            System.out.println("✅ JSON 파일 저장 완료: " + fileName);
        } catch (IOException e) {
            System.err.println("❌ 파일 저장 실패: " + e.getMessage());
        }
    }
}

