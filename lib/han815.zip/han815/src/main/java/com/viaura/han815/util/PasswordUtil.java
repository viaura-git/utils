package com.viaura.han815.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Slf4j
public class PasswordUtil {

    private static final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    /**
     * 비밀번호를 BCrypt 해시로 암호화
     */
    public static String encrypt(String rawPassword) {
        return encoder.encode(rawPassword);
    }

    /**
     * 비밀번호 일치 여부 확인
     */
    public static boolean matches(String rawPassword, String encodedPassword) {
        return encoder.matches(rawPassword, encodedPassword);
    }

    public static void main(String[] args) {
        String raw = "1234";
        String encoded = encrypt(raw);
        System.out.println("Raw Password: " + raw);
        System.out.println("Encoded Password: " + encoded);

        System.out.println("Matches? " + matches(raw, encoded)); // true
    }
}
