if (!window.stompClient) {
    window.stompClient = null;
    console.log("-----> window.stompClient null")
}

function connectWebSocket(siteId) {

    if (window.stompClient && window.stompClient.connected) {
        console.log("이미 연결된 stompClient 있음, 재연결 생략");
        return;
    }

    // console.log("-----> loggedInSiteId : " + siteId);
    // console.log("-----> connectWebSocket() start")

    const socket = new SockJS('/ws');
    const client = Stomp.over(socket);

    client.connect({}, function () {

        client.subscribe(`/topic/deposit/${siteId}`, function (message) {
            // console.log("-----> deposit message : ", message);
            const payload = JSON.parse(message.body);
            showToast(payload.message + " (금액: " + payload.amount + "원)");
        });
        console.log("-----> /topic/deposit/siteid WebSocket 연결됨");

        client.subscribe(`/topic/member/${siteId}`, function (message) {
            // console.log("-----> member message : ", message);
            const payload = JSON.parse(message.body);
            showToast(payload.memberId + payload.message);
        });
        console.log("-----> /topic/member/siteid WebSocket 연결됨");

        window.stompClient = client;
    });

}

function showToast(message) {
    console.log("--------> showToast 시작 ");
    console.log("--------> message : ", message);
    const toast = document.createElement("div");
    toast.innerText = message;
    toast.className = "toast";
    document.body.appendChild(toast);

    setTimeout(() => toast.remove(), 5000);
}

// bank select - member-register.html 이 열릴때만 getAllBanks() 를 호출한다
function tryInitBankSelect() {
    const path = window.location.pathname;
    //mebers 의 id ---> 예약어라서 javascript에서 읽지 못하는 듯
    const filename = path.substring(path.lastIndexOf('/') + 1);
    console.log(filename);
    if(filename === "register"){
        getAllBanks();
    }
}

let isBankListLoaded = false;

function getAllBanks() {
    if (isBankListLoaded) return; // 이미 불러왔으면 생략

    fetch("/api/banks")
        .then(res => res.json())
        .then(banks => {
            const select = document.getElementById("bankCode");
            banks.forEach(bank => {
                const option = document.createElement("option");
                option.value = bank.code;
                option.text = bank.name;
                select.appendChild(option);
            });

            isBankListLoaded = true; // flag 설정
        });
}


let isCheckedMemberId  = false;

//ID 중복체크
function checkDuplicateId() {
    const memberId = document.getElementById("memberId").value.trim();
    const messageEl = document.getElementById("memberIdValidation");
    const hiddenIsCheckedMemberId = document.getElementById("isCheckedMemberId");

    if (!memberId) {
        messageEl.innerText = "아이디를 입력하세요.";
        messageEl.style.color = "red";
        isCheckedMemberId = false;
        hiddenIsCheckedMemberId.value = "false";
        return;
    }

    fetch(`/api/site/members/check-duplicate?memberId=${encodeURIComponent(memberId)}`)
        .then(res => {
            //로그인 세션을 최우선으로 체크한다
            if(res.status === 401) {
                alert("세션이 만료되었습니다. 다시 로그인 해주세요.");
                window.location.href = "/login"; // 또는 로그인 모달 띄우기
                return;
            }
            // 그 외 에러를 메시지를 받아 처리한다
            if (!res.ok) {
                // ❗400 등 오류 응답이지만 body에 메시지가 있을 수 있음
                return res.text().then(errorMessage => {
                    throw new Error(errorMessage);
                });
            }
            return res.json();
        })
        .then(isDuplicate => {
            if (isDuplicate) {
                messageEl.innerText = "이미 존재하는 아이디입니다.";
                messageEl.style.color = "red";
                hiddenIsCheckedMemberId.value ="false";
                isCheckedMemberId = false;
            } else {
                messageEl.innerText = "사용 가능한 아이디입니다.";
                messageEl.style.color = "green";
                hiddenIsCheckedMemberId.value ="true";
                isCheckedMemberId = true;
            }
        })
        .catch(err => {
            console.error("에러 메시지:", err.message);
            messageEl.innerText = err.message || "중복 체크 중 오류가 발생했습니다.";
            messageEl.style.color = "red";
        });
}


// onLoad() 시 로그인 여부로 wesocket 열기
// member-register.html 이 열린다면 은행리스트 가져오기
document.addEventListener("DOMContentLoaded", () => {
    if (window.loggedInSiteId && window.loggedInSiteId !== 'guest') {
        connectWebSocket(window.loggedInSiteId);
    }

    tryInitBankSelect();
});




//null 값 체크
function isBlank(value) {
    return value == null || value.trim() === "";
}

function isNumeric(bankIdentifier){
    const regex = /^[0-9]+$/;
    return regex.test(bankIdentifier);
}

//패스워드 보이기
function togglePasswordVisibility(inputId, iconEl) {
    const input = document.getElementById(inputId);
    const isPassword = input.type === "password";
    input.type = isPassword ? "text" : "password";
    iconEl.classList.toggle('fa-eye');
    iconEl.classList.toggle('fa-eye-slash');
    input.focus();
}



function toLocalDateTime(dateStr, isStart) {
    if (isBlank(dateStr)) {
        const now = new Date(Date.now() + 9 * 60 * 60 * 1000); // KST로 변환
        const todayStr = now.toISOString().slice(0, 10); // YYYY-MM-DD
        return isStart ? "2000-01-01T00:00:00" : `${todayStr}T23:59:59`;
    }
    return isStart ? `${dateStr}T00:00:00` : `${dateStr}T23:59:59`;
}

function renderPagination(_links, pageInfo) {
    console.log("--------> pageInfo :", pageInfo);
    const paginationContainer = document.getElementById("pagination");
    if (!paginationContainer) return;

    paginationContainer.innerHTML = "";

    const currentPage = pageInfo.number;
    const totalPages = pageInfo.totalPages;

    const maxDisplayPages = 5;
    const half = Math.floor(maxDisplayPages / 2);
    let start = Math.max(0, currentPage - half);
    let end = Math.min(totalPages - 1, currentPage + half);

    if (end - start + 1 < maxDisplayPages) {
        if (start === 0) {
            end = Math.min(start + maxDisplayPages - 1, totalPages - 1);
        } else if (end === totalPages - 1) {
            start = Math.max(0, end - maxDisplayPages + 1);
        }
    }

    const createButton = (label, onClick, disabled = false, isActive = false) => {
        const btn = document.createElement("button");
        btn.textContent = label;
        btn.style.margin = "0 4px";
        btn.className = isActive ? "active-page" : "";

        if (disabled) {
            btn.disabled = true;
        } else {
            btn.addEventListener("click", onClick);
        }

        paginationContainer.appendChild(btn);
    };

    const createEllipsis = () => {
        const span = document.createElement("span");
        span.textContent = "...";
        span.style.margin = "0 4px";
        paginationContainer.appendChild(span);
    };

    // 처음 / 이전
    createButton("처음", () => loadTransactionPageFromUrl(_links.first?.href), !_links.first);
    createButton("이전", () => loadTransactionPageFromUrl(_links.prev?.href), !_links.prev);

    // 숫자 페이지
    if (start > 0) createEllipsis();

    for (let i = start; i <= end; i++) {
        const pageLink = updatePageParam(_links.self.href, i);
        createButton((i + 1).toString(), () => loadTransactionPageFromUrl(pageLink), false, i === currentPage);
    }

    if (end < totalPages - 1) createEllipsis();

    // 다음 / 끝
    createButton("다음", () => loadTransactionPageFromUrl(_links.next?.href), !_links.next);
    createButton("끝", () => loadTransactionPageFromUrl(_links.last?.href), !_links.last);
}

function setSearchCount(count){
    console.log("count : "+count);
    const searchCount = document.getElementById("search-total-count");
    searchCount.innerHTML = count.toLocaleString();
}

// page 파라미터를 변경하는 유틸
function updatePageParam(url, newPageNumber) {
    const urlObj = new URL(url, window.location.origin);
    urlObj.searchParams.set("page", newPageNumber);
    return urlObj.toString();
}

// 실제로 페이지를 가져오는 함수

async function fetchPage(url) {
    console.log("----> fetchPage() url : ", url);
    const res = await fetch(url);
    if (!res.ok) throw new Error("페이지 요청 실패");
    return res.json();
}

function initPagination(formData){
    console.log("initPagination start !!!");
    const page = 0;
    const size = 10;

    // ✅ select box도 10으로 변경
    const select = document.getElementById("page-size-select");
    if (select) {
        select.value = String(size); // "10"으로 강제 설정
    }
    //for debug
    for (const [key, value] of formData.entries()) {
        if (!isBlank(value)) {
            console.log(key + " : " + value);
        }
    }

    formData.set("from", toLocalDateTime(formData.get("from"), true));
    formData.set("to",   toLocalDateTime(formData.get("to"), false));
    formData.set("page", page);
    formData.set("size", size);

    return formData;
}


function onSizeChange(selectElement) {
    const selectedSize = selectElement.value;

    const apiUrl = selectElement.dataset.apiUrl;
    if (!apiUrl) {
        console.error("data-api-url 속성이 없습니다.");
        return;
    }
    const params = new URLSearchParams(selectElement.dataset.params);

    params.set('size', selectedSize);
    params.set('page', 0); // 사이즈 바뀌면 첫 페이지부터

    const fullUrl = `${apiUrl}?${params.toString()}`;
    console.log("onSizeChange → fullUrl:", fullUrl);

    if (typeof loadTransactionPageFromUrl === "function") {
        loadTransactionPageFromUrl(fullUrl);
    } else {
        console.warn("loadTransactionPageFromUrl 함수가 정의되지 않았습니다.");
    }
}
