// 초기 차트, 입금액 로딩
window.addEventListener("load", () => {
    loadTransactionChart();         // 기존 차트 로딩
    loadTodayHQDepositTotal();   // 오늘 입금금액 로딩
});

let chartType = 'bar';
let depositChart;


function switchChartType(type) {
    depositChart.config.type = type;
    depositChart.update();

    // 버튼 active 스타일 업데이트
    const buttons = document.querySelectorAll(".chart-header button");
    buttons.forEach(btn => {
        btn.classList.remove("active");
        if (btn.textContent.includes(type === 'bar' ? '막대' : '꺾')) {
            btn.classList.add("active");
        }
    });
}

function loadTransactionChart() {
    fetch("/api/site/transactions/chart/today")
        .then(res => res.json())
        .then(data => {
            const ctx = document.getElementById("transaction-chart").getContext("2d");

            const labels = Array.from({ length: 24 }, (_, i) => `${i}시`);
            const depositAmounts = new Array(24).fill(0);
            const depositCounts = new Array(24).fill(0);
            const withdrawalAmounts = new Array(24).fill(0);
            const withdrawalCounts = new Array(24).fill(0);

            data.forEach(entry => {
                const hour = entry.hour;
                if (entry.type === "DEPOSIT") {
                    depositAmounts[hour] = entry.amount;
                    depositCounts[hour] = entry.count;
                } else if (entry.type === "WITHDRAWAL") {
                    withdrawalAmounts[hour] = entry.amount;
                    withdrawalCounts[hour] = entry.count;
                }
            });

            const chartData = {
                labels: labels,
                datasets: [
                    {
                        label: "입금합계 (원)",
                        data: depositAmounts,
                        countData: depositCounts,
                        borderColor: "blue",
                        backgroundColor: "rgba(0, 102, 255, 0.5)",
                        fill: chartType === 'line',
                        tension: 0.3
                    },
                    {
                        label: "출금합계 (원)",
                        data: withdrawalAmounts,
                        countData: withdrawalCounts,
                        borderColor: "green",
                        backgroundColor: "rgba(0, 200, 0, 0.35)", // ✅ 녹색 + 채도 약함
                        fill: chartType === 'line',
                        tension: 0.3
                    }
                ]
            };

            if (depositChart) {
                depositChart.destroy();
            }

            depositChart = new Chart(ctx, {
                type: chartType,
                data: chartData,
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    layout: {
                      padding: { bottom: 20 },
                    },
                    plugins: {
                        legend: {
                            position: 'top',
                            labels: {
                                font: { size: 18 },  // ← 입금합계 / 출금합계 범례 크기
                                padding: 20
                            }
                        },
                        tooltip: {
                            bodyFont: {
                                size: 18  // ← 툴팁 내용 글자 크기
                            },
                            titleFont: {
                                size: 16  // ← 툴팁 제목 (시간) 글자 크기
                            },
                            mode: 'index',
                            intersect: false,
                            position: 'nearest',
                            callbacks: {
                                label: function (ctx) {
                                    const hour = ctx.label;
                                    const amount = ctx.raw ?? 0;
                                    const count = ctx.dataset.countData?.[ctx.dataIndex] ?? 0;
                                    return `${ctx.dataset.label} - ${hour}: ${amount.toLocaleString()}원, ${count}건`;
                                }
                            }
                        }
                    },
                    interaction: {
                        mode: 'index',
                        intersect: false
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: { font: { size: 18 } },
                            title: { display: true, text: '금액 (원)', font: { size: 18 } }
                        },
                        x: {
                            ticks: { font: { size: 18 } },
                            title: { display: true, text: '시간', font: { size: 18 } }
                        }
                    }
                }
            });
        });
}



function loadTodayHQDepositTotal() {
    console.log("------> loadTodayHQDepositTotal()");

    const params = new URLSearchParams();
    let from = getTodayLocalDate();
    let to = getTodayLocalDate();

    params.append("from", toLocalDateTime(from, true));
    params.append("to", toLocalDateTime(to, false));
    params.append("transactionType", "DEPOSIT");

    console.log("params.toString() : " + params.toString())

    fetch(`/api/hq/transactions?${params.toString()}`)
        .then(response => {
            if (!response.ok) {
                throw new Error("서버 응답 실패");
            }
            return response.json();
        })
        .then(data => {
            console.log("loadTodayDepositTotal() data: ", data);
            const totalAmount = data.totalAmount ?? 0;
            document.getElementById("today-total-deposit").innerText = totalAmount.toLocaleString();
            document.getElementById("today-total-commission").innerText = data.commFee.toLocaleString();
        })
        .catch(error => {
            console.error("오늘 입금 금액 로딩 실패:", error);
            document.getElementById("today-total-amount").innerText = "오류";
        });
}

function getTodayLocalDate(){
    const now = new Date();
    const yyyy = now.getFullYear();
    const mm = String(now.getMonth() + 1).padStart(2, '0');
    const dd = String(now.getDate()).padStart(2, '0');
    let to = `${yyyy}-${mm}-${dd}`;

    return to;
}

function calcTodayCommission(amount, ratio){
    return amount*ratio;
}

