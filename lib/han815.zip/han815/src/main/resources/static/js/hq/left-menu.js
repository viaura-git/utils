function toggleMenus() {
    document.querySelectorAll('.accordion-toggle').forEach(toggle => {
        toggle.addEventListener('click', function () {
            // 1. 모든 submenu 닫기
            document.querySelectorAll('.submenu').forEach(menu => {
                if (menu !== this.nextElementSibling) {
                    menu.classList.remove('open');
                }
            });

            // 2. 현재 submenu 토글 (열려있으면 닫히고, 닫혀있으면 열림)
            this.nextElementSibling.classList.toggle('open');
        });
    });
}

document.addEventListener("DOMContentLoaded", toggleMenus);

