document.addEventListener("DOMContentLoaded", () => {
    // 1. 최초 페이지 로딩 시 검색 실행 (조건 없이)
    searchDepositsBySite();

    // 2. input에서 Enter 키 누르면 검색 실행
    const searchButton = document.getElementById("search-button");
    if (searchButton) {
        searchButton.addEventListener("click", searchDepositsBySite);
    }

    const searchForm = document.getElementById("search-form");

    if (searchForm && searchButton) {
        const inputs = searchForm.querySelectorAll("input");

        inputs.forEach(input => {
            input.addEventListener("keydown", function (event) {
                if (event.key === "Enter") {
                    event.preventDefault();
                    searchButton.click();
                }
            });
        });
    }

});

async function loadTransactionPageFromUrl(url) {
    console.log("-----> loadTransactionPageFromUrl() start, url : ", url);
    const data = await fetchPage(url);
    console.log("loadTransactionPageFromUrl()  data : ", data);

    const deposits = data._embedded?.transactionHistoryRecords || [];

    renderDepositTable(deposits, data.page); // 테이블 렌더링 함수
    renderPagination(data._links, data.page); // 페이지네이션 생성
    setSearchCount(data.page.totalElements);
}

function searchDepositsBySite() {
    const form = document.getElementById("search-form");
    let formData = new FormData(form);

    const select = document.getElementById("page-size-select");

    //검색을 눌렀다는 것은 조건이 변경되어 발생한 일이므로, 모든걸 초기화 한다
    // size 변경, page 변경 등은 자체 URL을 _link 로 갖고 있으므로 dataset에 저장된다
    formData = initPagination(formData);

    const params = new URLSearchParams();
    for (const [key, value] of formData.entries()) {
        if (!isBlank(value)) {
            params.append(key, value.trim());
        }
    }
    select.dataset.params = params.toString();
    select.dataset.apiUrl = '/api/site/transaction/history';

    const apiUrl = select?.dataset.apiUrl || '/api/site/transaction/history';
    const url = `${apiUrl}?${params.toString()}`;

    console.log("Final request URL --->", url);
    loadTransactionPageFromUrl(url);
}

function renderDepositTable(deposits, pageInfo) {

    console.log("------> renderDepositTable() start")
    const tbody = document.getElementById("deposit-table-body");
    tbody.innerHTML = "";

    if (!deposits || deposits.length === 0) {
        console.log("----> no data");
        tbody.innerHTML = "<tr><td colspan='12'>검색 결과가 없습니다.</td></tr>";
        return;
    }

    //-------------------------------------//
    //------- table body 생성 --------------//
    //-------------------------------------//

    console.log("content length:", deposits.length);

    deposits.forEach((item, index) => {

        const rowNumber = pageInfo.number * pageInfo.size + index + 1; // 1부터 시작하는 전체 순번
        const row = document.createElement("tr");

        const linkedMemberId = '<a href="/site/members?memberId='+ item.memberId +'">' + item.memberId + '</a>' ;

        row.innerHTML = `
        <td>${rowNumber}</td>
        <td>${linkedMemberId}</td>
        <td>${item.depositPaymentCompanyId}</td>
        <td>${item.depositPaymentId}</td>
        <td>${item.amount.toLocaleString()}</td>
        <td>${item.distCommRate.toFixed(2)}</td>
        <td>${item.distCommFee.toLocaleString()}</td>
        <td>${item.hqCommRate.toFixed(2)}</td>
        <td>${item.hqCommFee.toLocaleString()}</td>
        <td>${item.balance.toLocaleString()}</td>
        <td>${item.siteId}</td>
        <td>${item.regDate.replace('T', ' ')}</td>
      `;
        tbody.appendChild(row);
    });

}

