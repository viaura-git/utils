
document.addEventListener("DOMContentLoaded", () => {
    searchDepositsByMember(); // 최초 0페이지, pageSize 10
});

//가상계좌 회수
function revokeVirtualAccount() {
    const mId = document.getElementById("member-mid").value;

    // Ajax 로 가상계좌 회수 요청
    if(confirm("가상계좌 회수 요청을 처리합니다. 회원이 입금불가 상태가 됩니다")){
        fetch(`/api/site/members/${mId}/depositInfo`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                depositBankCode: null,
                depositBankName: null,
                depositBankAccount: null
            })
        })
            .then(res => {
                if (res.ok) {
                    alert("가상계좌 정보가 삭제되었습니다.");
                    location.reload(); // 또는 동적 업데이트
                } else {
                    alert("가상계좌 삭제 실패");
                }
            });
    } else {return false;}

}

function deleteMember() {
    const id = document.getElementById("member-mid").value;

    if (confirm("가상계좌가 있다면 회수하고, 회원을 삭제합니다 \n 정말 삭제하시겠습니까?")) {
        // 삭제 요청 로직
        //alert("삭제 요청 처리 중...");
        fetch(`/api/site/members/${id}/status`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                deleted : true
            })
        })
            .then(res => {
                if (res.ok) {
                    alert("회원이 삭제되었습니다.");
                    location.reload(); // 또는 동적 업데이트
                } else {
                    alert("회원 삭제 실패");
                }
            });
    } else { return false; }
}

function setMemberStatus(status) {
    const id = document.getElementById("member-mid").value;
    console.log("id:", id);

    const isEnabling = status === true;
    const confirmMessage = isEnabling
        ? "회원을 활성화 하시겠습니까?"
        : "회원을 비활성화 합니다.\n비활성 회원이라도 가상계좌가 있다면 입금 가능합니다.\n정말 비활성화하시겠습니까?";
    const successMessage = isEnabling
        ? "회원이 활성화 되었습니다."
        : "회원이 비활성 되었습니다.";
    const failureMessage = isEnabling
        ? "회원 활성화 실패"
        : "회원 비활성화 실패";

    if (!confirm(confirmMessage)) return;

    fetch(`/api/site/members/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: status })
    })
        .then(res => {
            if (res.ok) {
                alert(successMessage);
                location.reload();
            } else {
                alert(failureMessage);
            }
        })
        .catch(err => {
            console.error("상태 변경 중 에러:", err);
            alert("요청 처리 중 오류가 발생했습니다.");
        });
}


function showTab(tabId) {

    console.log("-----> showTab() tabId : ", tabId);
    // 모든 탭 내용 숨기기
    document.querySelectorAll(".tab-content").forEach(el => el.classList.remove("active"));
    // 모든 탭 버튼 비활성화
    document.querySelectorAll(".tabs .tab").forEach(el => el.classList.remove("active"));
    // 선택된 탭만 보여주기
    document.getElementById(tabId).classList.add("active");
    document.querySelector(`.tabs .tab[onclick*="${tabId}"]`).classList.add("active");

    if(tabId === "deposit") {
        searchDepositsByMember();
    } else if(tabId === "withdrawal") {
        searchWithdrawalsByMember();
    }
}

async function loadTransactionPageFromUrl(url) {
    console.log("-----> loadTransactionPageFromUrl() start, url : ", url);

    // 1. URL에서 transactionType 파라미터 추출
    const urlObj = new URL(url, window.location.origin); // 상대 URL 보완
    const transactionType = urlObj.searchParams.get("transactionType");
    console.log("transactionType:", transactionType);

    const data = await fetchPage(url);
    console.log("loadTransactionPageFromUrl()  data : ", data);

    const transactions = data._embedded?.transactionHistoryRecords || [];

    if(transactionType === "DEPOSIT") {
        renderDepositsByMemberTable(transactions, data.page); // 테이블 렌더링 함수
    } else if (transactionType === "WITHDRAWAL") {
        renderWithdrawalByMemberTable(transactions, data.page); // 테이블 렌더링 함수
    }
    renderPagination(data._links, data.page); // 페이지네이션 생성
    setSearchCount(data.page.totalElements);
}

function searchDepositsByMember() {
    console.log("-----> searchDepositsByMember() start");
    const form = document.getElementById("deposit-search-form");
    let formData = new FormData(form);

    const select = document.getElementById("page-size-select");

    //검색을 눌렀다는 것은 조건이 변경되어 발생한 일이므로, 모든걸 초기화 한다
    // size 변경, page 변경 등은 자체 URL을 _link 로 갖고 있으므로 dataset에 저장된다
    formData = initPagination(formData);

    const params = new URLSearchParams();
    for (const [key, value] of formData.entries()) {
        if (!isBlank(value)) {
            params.append(key, value.trim());
        }
    }
    select.dataset.params = params.toString();
    select.dataset.apiUrl = '/api/site/transaction/history';
    console.log("-----> searchDepositsByMember() apiUrl ----> " + select.dataset.apiUrl);
    console.log("-----> searchDepositsByMember() params.toString() ----> " + params.toString());

    const apiUrl = select?.dataset.apiUrl || '/api/site/transaction/history';
    const url = `${apiUrl}?${params.toString()}`;

    console.log("Final request URL --->", url);
    loadTransactionPageFromUrl(url);
}

function searchWithdrawalsByMember() {
    console.log("-----> searchWithdrawalsByMember() start");
    const form = document.getElementById("withdrawal-search-form");
    let formData = new FormData(form);

    const select = document.getElementById("page-size-select");

    //검색을 눌렀다는 것은 조건이 변경되어 발생한 일이므로, 모든걸 초기화 한다
    // size 변경, page 변경 등은 자체 URL을 _link 로 갖고 있으므로 dataset에 저장된다
    formData = initPagination(formData);

    const params = new URLSearchParams();
    for (const [key, value] of formData.entries()) {
        if (!isBlank(value)) {
            params.append(key, value.trim());
        }
    }
    select.dataset.params = params.toString();
    select.dataset.apiUrl = '/api/site/transaction/history';
    console.log("-----> searchWithdrawalsByMember() apiUrl ----> " + select.dataset.apiUrl);
    console.log("-----> searchWithdrawalsByMember() params.toString() ----> " + params.toString());

    const apiUrl = select?.dataset.apiUrl || '/api/site/transaction/history';
    const url = `${apiUrl}?${params.toString()}`;

    console.log("Final request URL --->", url);
    loadTransactionPageFromUrl(url, 'withdrawals');
}

function renderDepositsByMemberTable(deposits, pageInfo) {

    console.log("------> renderDepositTable() start")
    const tbody = document.getElementById("deposit-table-body");
    tbody.innerHTML = "";

    if (!deposits || deposits.length === 0) {
        console.log("----> no data");
        tbody.innerHTML = "<tr><td colspan='5'>검색 결과가 없습니다.</td></tr>";
        return;
    }

    //-------------------------------------//
    //------- table body 생성 --------------//
    //-------------------------------------//

    console.log("content length:", deposits.length);

    deposits.forEach((item, index) => {
        const rowNumber = pageInfo.number * pageInfo.size + index + 1; // 1부터 시작하는 전체 순번
        const row = document.createElement("tr");
        row.innerHTML = `
        <td>${rowNumber}</td>
        <td>${item.regDate.replace('T', ' ')}</td>
        <td style="text-align: right;">${item.amount.toLocaleString()}</td>
        <td style="text-align: right;">${(item.distCommFee + item.hqCommFee).toLocaleString()}</td>
        <td style="text-align: right;">${item.balance.toLocaleString()}</td>
        
      `;
        tbody.appendChild(row);
    });

}

function renderWithdrawalByMemberTable(withdrawals, pageInfo) {

    console.log("------> renderDepositTable() start")
    const tbody = document.getElementById("withdrawal-table-body");
    tbody.innerHTML = "";

    if (!withdrawals || withdrawals.length === 0) {
        console.log("----> no data");
        tbody.innerHTML = "<tr><td colspan='6'>검색 결과가 없습니다.</td></tr>";
        return;
    }

    //-------------------------------------//
    //------- table body 생성 --------------//
    //-------------------------------------//

    console.log("content length:", withdrawals.length);

    withdrawals.forEach((item, index) => {
        const rowNumber = pageInfo.number * pageInfo.size + index + 1;

        const row = document.createElement("tr");

        // 조건에 따라 balance 표시
        const balance =
            item.status === "CONFIRMED" && item.withdrawalDate
                ? item.balance.toLocaleString()
                : "";

        // 조건에 따라 withdrawalDate 출력
        const withdrawalDate = item.withdrawalDate
            ? item.withdrawalDate.replace('T', ' ')
            : "";

        row.innerHTML = `
        <td>${rowNumber}</td>
        <td>${item.withdrawalStatus}</td>
        <td>${item.regDate.replace('T', ' ')}</td>
        <td style="text-align: right;">${item.amount.toLocaleString()}</td>
        <td>${withdrawalDate}</td>
        <td>${balance}</td>
    `;

        tbody.appendChild(row);
    });

}


function showDepositForm() {
    document.getElementById("deposit-register-form").style.display = "block";
    document.getElementById("deposit-register-button").style.display = "none";
    getAllBanks();
}


function cancelDepositForm() {
    document.getElementById("deposit-register-form").style.display = "none";
    document.getElementById("deposit-register-button").style.display = "inline-block";

    // 입력 필드 초기화 (선택사항)
    document.getElementById("depositBankName").value = "";
    document.getElementById("depositBankAccount").value = "";
}

function submitDepositAccount() {

    const registerForm = document.getElementById("deposit-register-form");


    if (!registerForm) {
        console.error("register-form이 존재하지 않음");
        return;
    }
    if(registerForm) {

        const formData = new FormData(registerForm);

        const bankCode = formData.get("bankCode")?.trim();
        const bankAccount = formData.get("depositBankAccount")?.trim();
        const id = formData.get("id").trim();
        // const bankHolder = document.getElementById("depositBankHolder").value.trim();
        console.log("bankCode:", bankCode);
        console.log("bankAccount:", bankAccount);

        // 오류 메시지 초기화
        document.getElementById("bankCodeValidation").textContent = "";
        document.getElementById("bankAccountValidation").textContent = "";
        // document.getElementById("error-bank-holder").textContent = "";

        let isValid = true;

        if (!bankCode) {
            document.getElementById("bankCodeValidation").textContent = "은행명을 입력해주세요.";
            isValid = false;
        }

        if (!bankAccount) {
            document.getElementById("bankAccountValidation").textContent = "계좌번호를 입력해주세요.";
            isValid = false;
        } else if (!/^[0-9\-]+$/.test(bankAccount)) {
            document.getElementById("bankAccountValidation").textContent = "숫자와 '-'만 입력 가능합니다.";
            isValid = false;
        }

        // if (!bankHolder) {
        //     document.getElementById("error-bank-holder").textContent = "예금주를 입력해주세요.";
        //     isValid = false;
        // }

        if (!isValid) return;

        // 통과 시 등록 로직
        console.log("가상계좌 등록 처리 중...");
        // TODO: Ajax 요청 등


        formData.append("bankCode", bankCode);

        fetch(`/api/site/members/${id}/depositInfo`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id: id,
                depositBankCode: bankCode,
                depositBankAccount: bankAccount
            })
        })
        .then(res => {
            if (res.ok) {
                alert("가상계좌 정보가 등록되었습니다.");
                location.reload(); // 또는 동적 업데이트
            } else {
                alert("등록 실패");
            }
        });

    }
}
