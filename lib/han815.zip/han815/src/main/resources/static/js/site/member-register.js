document.addEventListener("DOMContentLoaded", () => {
    //submit 액션 등록
    const registerForm = document.getElementById("register-form");
    if (!registerForm) {
        console.error("register-form이 존재하지 않음");
        return;
    }

    if (registerForm) {
        //e.preventDefault()는 submit 이벤트에서만 호출한다
        //validate에는 사용하지 않는다
        registerForm.addEventListener("submit", function(e) {
            e.preventDefault();

            const formData = new FormData(registerForm);
            console.log("memberId:", formData.get("memberId")); // 여기가 찍혀야 정상

            const isValid = validateAllRegisterForm(formData);

            if (!isValid) {
                e.preventDefault();
                return;
            } // 유효성 실패 시 중단

            const registerData = Object.fromEntries(formData.entries());

            fetch("/api/site/members", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(registerData)
            })
                .then(res => res.json())
                .then(data => {
                    console.log("응답:", data);
                    window.location.href = "/site/members/"+data.mid;  // 원하는 성공 페이지 URL로 변경
                });
        });
    } else {
        console.warn("⚠️ register-form not found. This page may not include the form.");
    }
});


function validateAllRegisterForm(formData){
    console.log("---> validateAllRegisterForm() start");

    const memberIdValidationMessageEl = document.getElementById("memberIdValidation");
    console.log("memberId : ", formData.get("memberId") );
    console.log("isCheckedMemberId : ", isCheckedMemberId);

    if (isBlank(formData.get("memberId"))){
        memberIdValidationMessageEl.innerText = "아이디를 입력하세요";
        memberIdValidationMessageEl.style.color = "red";
        document.getElementById("memberId").focus();
        return;
    }
    if(!isCheckedMemberId || isBlank(formData.get("isCheckedMemberId"))){
        memberIdValidationMessageEl.innerText = "아이디 중복체크를 해주세요";
        memberIdValidationMessageEl.style.color = "red";
        document.getElementById("memberId").focus();
        return;
    }
    if(!validateMemberId(formData.get("memberId"))) {
        memberIdValidationMessageEl.innerText = "아이디는 4~15자의 영문자와 숫자만 입력 가능합니다.";
        memberIdValidationMessageEl.style.color = "red";
        document.getElementById("memberId").focus();
        return;
    }
    memberIdValidationMessageEl.innerText = "";


    const passwordValidationMessageEl = document.getElementById("passwordValidation");
    if (isBlank(formData.get("password"))){
        passwordValidationMessageEl.innerText = "비밀번호를 입력해주세요";
        passwordValidationMessageEl.style.color = "red";
        document.getElementById("password").focus();
        return;
    }
    if (!validatePassword(formData.get("password"))) {
        passwordValidationMessageEl.innerText="비밀번호는 8~15자이며, 대문자, 소문자, 숫자, 특수문자를 모두 포함해야 합니다";
        passwordValidationMessageEl.style.color = "red";
        document.getElementById("password").focus();
        return;
        // alert("비밀번호는 8~15자이며, 대문자, 소문자, 숫자, 특수문자를 모두 포함해야 합니다.");
    }
    passwordValidationMessageEl.innerText = "";

    const phoneValidationMessageEl = document.getElementById("phoneValidation");
    if (isBlank(formData.get("phone"))){
        phoneValidationMessageEl.innerText = "전화번호를 입력해 주세요";
        phoneValidationMessageEl.style.color = "red";
        document.getElementById("phone").focus();
        return;
    }
    if (!validatePhone(formData.get("phone"))) {
        phoneValidationMessageEl.innerText = "전화번호 형식은 010-0000-0000 이어야 합니다";
        phoneValidationMessageEl.style.color = "red";
        document.getElementById("phone").focus();
        return;
        //alert("전화번호 형식은 010-0000-0000 이어야 합니다.");
    }
    phoneValidationMessageEl.innerText = "";

    const bankCodeValidationMessageEl = document.getElementById("bankCodeValidation");
    if(isBlank(formData.get("bankCode"))){
        bankCodeValidationMessageEl.innerText = "은행을 선택하세요";
        bankCodeValidationMessageEl.style.color = "red";
        document.getElementById("bankCode").focus();
        return;
    }
    bankCodeValidationMessageEl.innerText = "";


    const bankAccountValidationMessageEl = document.getElementById("bankAccountValidation");
    if (isBlank(formData.get("bankAccount"))){
        bankAccountValidationMessageEl.innerText = "계좌번호를 입력하세요";
        bankAccountValidationMessageEl.style.color = "red";
        document.getElementById("bankAccount").focus();
        return;
    }
    if (!validateBankAccount(formData.get("bankAccount"))) {
        bankAccountValidationMessageEl.innerText = "숫자와 -(하이픈) 만 가능합니다";
        bankAccountValidationMessageEl.style.color = "red";
        document.getElementById("bankAccount").focus();
        return;
        //alert("숫자와 -(하이픈) 만 가능합니다 ");
    }
    bankAccountValidationMessageEl.innerText = "";

    //예금주 체크
    const bankAccountHolerValidationMessageEl = document.getElementById("bankAccountHolderValidation");
    if (isBlank(formData.get("bankAccount"))){
        bankAccountHolerValidationMessageEl.innerText = "예금주를 입력하세요";
        bankAccountHolerValidationMessageEl.style.color = "red";
        document.getElementById("bankAccount").focus();
        return;
    }
    if (!validateKoreanEnglishOnly(formData.get("bankAccountHolder"))) {
        bankAccountHolerValidationMessageEl.innerText = "이름은 한글과 영문만 입력 가능합니다";
        bankAccountHolerValidationMessageEl.style.color = "red";
        //alert("이름은 한글과 영문만 입력 가능합니다.");
        document.getElementById("bankAccountHolder").focus();
        return;
    }
    bankAccountHolerValidationMessageEl.innerText = "";

    const bankIdentifierValidationEl = document.getElementById("bankIdentifierValidation");
    if(isBlank(formData.get("bankIdentifier"))){
        bankIdentifierValidationEl.innerText = "개인은 생년월일 YYMMDD 6자리, 사업자는 사업자번호 10자리입니다";
        bankIdentifierValidationEl.style.color = "red";
        document.getElementById("bankIdentifier").focus();
        return;
    }
    if(!validateLength(formData.get("bankIdentifier"))){
        bankIdentifierValidationEl.innerText = "개인은 생년월일 YYMMDD 6자리, 사업자는 사업자번호 10자리입니다";
        bankIdentifierValidationEl.style.color = "red";
        document.getElementById("bankIdentifier").focus();
        return;
    }
    if(!isNumeric(formData.get("bankIdentifier"))){
        bankIdentifierValidationEl.innerText = "오직 숫자만 가능합니다 개인 생년월일 YYMMDD, 사업자번호";
        bankIdentifierValidationEl.style.color = "red";
        document.getElementById("bankIdentifier").focus();
        return;
    }
    bankIdentifierValidationEl.innerText = "";

    return true;

}

function validateMemberId(memberId) {
    console.log("----> validateMemberId() start : memberId is ",memberId);
    const regex = /^[a-zA-Z0-9]{4,15}$/;
    return regex.test(memberId);
}

function validatePassword(password) {
    console.log("----> validatePassword() start : password is ",password);
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,15}$/;
    return regex.test(password);
}

function validatePhone(phone) {
    console.log("----> validatePhone() start : phone is ",phone);
    const regex = /^010-\d{4}-\d{4}$/;
    return regex.test(phone);
}

function validateBankAccount(bankAccount) {
    console.log("----> validateBankAccount() start : bankAccount is ", bankAccount);
    const regex = /^[0-9\-]+$/;
    return regex.test(bankAccount);
}

function validateKoreanEnglishOnly(bankAccountHolder) {
    console.log("----> validateKoreanEnglishOnly() start : bankAccountHolder is ", bankAccountHolder);
    const regex = /^[가-힣a-zA-Z]+$/;
    return regex.test(bankAccountHolder);
}

function validateLength(bankIdentifier) {
    console.log("----> validateBankIdentifier() start : bankIdentifier is ", bankIdentifier);
    if(bankIdentifier.length === 6 || bankIdentifier.length === 10){
        return true;
    } else return false;
}

function isValidSelect(){
    const bankCode = document.getElementById("bankCode");
    // console.log("bankCode : ", bankCode);
    const bankCodeValidationMessageEl = document.getElementById("bankCodeValidation");
    if(bankCode.value !== ""){
        bankCodeValidationMessageEl.innerText = "";
    }else {
        bankCodeValidationMessageEl.innerText = "은행을 선택하세요";
        return false;
    }

    return true;
}
