document.addEventListener("DOMContentLoaded", () => {
    getSiteBalance();


    document.getElementById("withdraw-button").addEventListener("click", () => {
        const payload = {
            memberMid: document.getElementById("member-mid").innerText,
            memberId: document.getElementById("member-id").innerText,
            withdrawalBankName: document.getElementById("withdrawal-bank-name").innerText,
            withdrawalBankCode: document.getElementById("withdrawal-bank-code").innerText,
            withdrawalBankAccount: document.getElementById("withdrawal-bank-account").innerText,
            withdrawalBankAccountHolder: document.getElementById("withdrawal-bank-account-holder").innerText,
            withdrawalBankIdentifier: document.getElementById("withdrawal-bank-identifier").innerText,
            withdrawalStatus: "NEW",
            type: "WITHDRAWAL",
            amount: parseInt(document.getElementById("amount").value)
        };

        console.log("====> payload : ", payload);

        fetch("/api/site/withdraw", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
        })
            .then(res => {
                if (!res.ok) throw new Error("출금 요청 실패");
                return res.json();
            })
            .then(data => {
                alert("출금 요청이 완료되었습니다.");
                console.log("응답:", data);
                window.location.href = "/site/members/withdrawals";
            })
            .catch(err => {
                console.error(err);
                alert("출금 요청 중 오류가 발생했습니다.");
            });
    });


    const memberIdInput = document.getElementById("memberId");
    memberIdInput.addEventListener("change", () => {
        getMemberInfo(memberIdInput.value);
    });
});

async function loadTransactionPageFromUrl(url) {
    console.log("-----> loadTransactionPageFromUrl() start, url : ", url);
    const data = await fetchPage(url);
    console.log("loadTransactionPageFromUrl()  data : ", data);

    const members = data._embedded?.members || [];

    fillMemberInfo(members);
}

async function getMemberInfo(memberId) {
    memberId = memberId.trim();
    if (!memberId) return; // 빈 값이면 요청하지 않음

    const params = new URLSearchParams();
    params.append("memberId", memberId);

    const url = '/api/site/members?'+params.toString();

    console.log("Final request URL --->", url);
    loadTransactionPageFromUrl(url);
}

function fillMemberInfo(members) {
    const errorDiv = document.getElementById("withdraw-error-message");
    const infoDiv = document.getElementById("withdrawal-info");

    // 모두 초기화 (처음에 숨김)
    errorDiv.style.display = "none";
    infoDiv.style.display = "none";

    if (!members || members.length === 0) {
        console.log("----> no data");

        // 에러 메시지만 표시
        errorDiv.innerText = "해당 회원 정보를 찾을 수 없습니다.";
        errorDiv.style.display = "block";

        return;
    }

    const member = members[0];

    // 에러 메시지 숨기고 정보 영역 보이기
    errorDiv.style.display = "none";
    infoDiv.style.display = "grid";  // 혹은 원래 사용하던 display

    // 값 채우기
    document.getElementById("member-mid").innerHTML = `<a href="/site/members/${member.mid}" target="_blank">${member.mid || "-"}</a>`;
    document.getElementById("member-id").innerText = member.memberId;
    document.getElementById("withdrawal-bank-name").innerText = member.bankName || "-";
    document.getElementById("withdrawal-bank-account").innerText = member.bankAccount || "-";
    document.getElementById("withdrawal-bank-code").innerText = member.bankCode || "-";
    document.getElementById("withdrawal-bank-account-holder").innerText = member.bankAccountHolder || "-";
    document.getElementById("withdrawal-bank-identifier").innerText = member.bankIdentifier || "-";
}

function withdraw(){

}









