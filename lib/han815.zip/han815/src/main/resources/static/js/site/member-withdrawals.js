document.addEventListener("DOMContentLoaded", () => {

    getSiteBalance();
    searchWithdrawalsBySite();

    // 2. input에서 Enter 키 누르면 검색 실행
    const searchButton = document.getElementById("withdrawal-search-button");
    if (searchButton) {
        searchButton.addEventListener("click", searchWithdrawalsBySite);
    }

    const searchForm = document.getElementById("withdrawal-search-form");

    if (searchForm && searchButton) {
        const inputs = searchForm.querySelectorAll("input");

        inputs.forEach(input => {
            input.addEventListener("keydown", function (event) {
                if (event.key === "Enter") {
                    event.preventDefault();
                    searchButton.click();
                }
            });
        });
    }

    // const withdrawalStatusSelect = document.getElementById("withdrawal-status-select");
    // if (withdrawalStatusSelect) {
    //     withdrawalStatusSelect.addEventListener("change", onWithdrawalStatusChange);
    // }

});

function confirmWithdraw(transactionId) {
    fetch("/api/site/withdraw", {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            tId: transactionId
        })
    })
    .then(res => {
        if (res.ok) {
            alert("출금이 완료되었습니다");
            location.reload(); // 또는 동적 업데이트
        } else {
            alert("등록 실패");
        }
    });
}

async function loadTransactionPageFromUrl(url) {
    console.log("-----> loadTransactionPageFromUrl() start, url : ", url);
    const data = await fetchPage(url);
    console.log("loadTransactionPageFromUrl()  data : ", data);

    const withdrawals = data._embedded?.transactionHistoryRecords || [];

    renderWithdrawalTable(withdrawals, data.page); // 테이블 렌더링 함수
    renderPagination(data._links, data.page); // 페이지네이션 생성
    setSearchCount(data.page.totalElements);
}

function searchWithdrawalsBySite() {

    const form = document.getElementById("withdrawal-search-form");
    let formData = new FormData(form);

    const select = document.getElementById("page-size-select");

    //검색을 눌렀다는 것은 조건이 변경되어 발생한 일이므로, 모든걸 초기화 한다
    // size 변경, page 변경 등은 자체 URL을 _link 로 갖고 있으므로 dataset에 저장된다
    formData = initPagination(formData);

    const params = new URLSearchParams();
    for (const [key, value] of formData.entries()) {
        if (!isBlank(value)) {
            params.append(key, value.trim());
        }
    }
    select.dataset.params = params.toString();
    select.dataset.apiUrl = '/api/site/transaction/history';

    const apiUrl = select?.dataset.apiUrl || '/api/site/transaction/history';
    const url = `${apiUrl}?${params.toString()}`;

    console.log("Final request URL --->", url);
    loadTransactionPageFromUrl(url);
}

function renderWithdrawalTable(withdrawals, pageInfo) {

    console.log("------> renderWithdrawalTable() start")
    const tbody = document.getElementById("withdrawal-table-body");
    tbody.innerHTML = "";

    if (!withdrawals || withdrawals.length === 0) {
        console.log("----> no data");
        tbody.innerHTML = "<tr><td colspan='12'>검색 결과가 없습니다.</td></tr>";
        return;
    }

    //-------------------------------------//
    //------- table body 생성 --------------//
    //-------------------------------------//

    console.log("content length:", withdrawals.length);

    withdrawals.forEach((item, index) => {
        const rowNumber = pageInfo.number * pageInfo.size + index + 1; // 1부터 시작하는 전체 순번
        const row = document.createElement("tr");

        const linkedMemberId = '<a href="/site/members?memberId='+ item.memberId +'">' + item.memberId + '</a>' ;

        const formattedStatus = item.withdrawalStatus === "CONFIRMED" ? "지급완료" : "신규신청";

        const formattedAmount = Number(item.amount).toLocaleString("ko-KR");
        const formattedBalance = item.withdrawalStatus === "CONFIRMED"
            ? Number(item.balance).toLocaleString("ko-KR") + "원"
            : "<button type='button' id='withdraw-exec-button' class='withdraw-exec-button' onclick='confirmWithdraw("+ item.tId +")'>출금완료</button>";
        const formattedRegDate = item.regDate?.replace('T', ' ') ?? '';
        const formattedWithdrawalDate = item.withdrawalDate?.replace('T', ' ') ?? '';

        const balanceAlign = item.withdrawalStatus === "CONFIRMED" ? "right" : "center";

        row.innerHTML = `
        <td>${rowNumber}</td>
        <td>${linkedMemberId}</td>
        <td>${formattedStatus}</td>
        <td style="text-align: right;">${formattedAmount}원</td>
        <td>${item.withdrawalBankName}</td>
        <td>${item.withdrawalBankAccount}</td>
        <td>${item.withdrawalBankAccountHolder}</td>
        <td>${item.withdrawalBankIdentifier}</td>
        <td style="text-align: ${balanceAlign};">${formattedBalance}</td>
        <td>${formattedRegDate}</td>
        <td>${formattedWithdrawalDate}</td>
    `;

        tbody.appendChild(row);
    });


}