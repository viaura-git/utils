document.addEventListener("DOMContentLoaded", () => {
    // 1. 최초 진입 시 검색, member list
    search();

    // // 2. 검색 버튼(submit) 클릭 시 Ajax 검색
    // const form = document.getElementById("member-search-form");
    //
    // form.addEventListener("submit", (e) => {
    //     e.preventDefault(); // 기본 폼 전송 막기
    //     searchMembers();
    // });
});

async function loadMembersPageFromUrl(url) {
    console.log("-----> loadMembersPageFromUrl() start, url : ", url);
    const data = await fetchPage(url);
    console.log("loadMembersPageFromUrl()  data : ", data);

    const members = data._embedded?.members || [];

    renderMembersTable(members, data.page); // 테이블 렌더링 함수
    renderPagination(data._links, data.page); // 페이지네이션 생성
    setSearchCount(data.page.totalElements);
}


function search() {
    console.log("-----> member-list search() start");

    const form = document.getElementById("search-form");
    let formData;
    if(form) formData = new FormData(form);

    const select = document.getElementById("page-size-select");

    // 동적으로 hidden input 조정
    const deletedCheckbox = document.getElementById("deletedCheckbox");
    if (deletedCheckbox && form && deletedCheckbox.checked) { formData.append("deleted", true); }

    const enabledCheckbox = document.getElementById("enabledCheckbox");
    if (enabledCheckbox && form && enabledCheckbox.checked) { formData.append("enabled", true); }

    const disabledCheckbox = document.getElementById("disabledCheckbox");
    if (disabledCheckbox && form && disabledCheckbox.checked) { formData.append("enabled",false); }

    formData = initPagination(formData);

    const params = new URLSearchParams();

    for (const [key, value] of formData.entries()) {
        if (value !== null && value !== "") {//값이 null 이 아닐때만 추가한다
            params.append(key, value);
        }
    }

    const apiUrl = select?.dataset.apiUrl || '/api/site/members';
    const url = `${apiUrl}?${params.toString()}`;

    console.log("Final request URL --->", url);
    loadMembersPageFromUrl(url);


    //
    // console.log("-----> searchEnabledMembers() params : ", params.toString());
    //
    // fetch(`/api/site/members?${params.toString()}`)
    //     .then(res => {
    //         console.log(res);
    //         //로그인 세션을 최우선으로 체크한다
    //         if(res.status === 401) {
    //             throw {status : 401, message: "세션이 만료되었습니다. 다시 로그인 해주세요."};
    //         }
    //         if(res.status === 404) {
    //             throw { status: 404, message: "회원이 없습니다" };
    //         }
    //         // 그 외 에러를 메시지를 받아 처리한다
    //         if (!res.ok) {
    //             // ❗400 등 오류 응답이지만 body에 메시지가 있을 수 있음
    //             if(res.status !== 401 || res.status !== 404) {
    //                 return res.text().then(errorMessage => {
    //                     throw {staus: res.status, message : errorMessage};
    //                 });
    //             }
    //         }
    //         return res.json();
    //     })
    //     .then(data => {
    //         console.log("data : ", data);
    //         renderMemberTable(data._embedded.members);
    //         const totalCount = data.page.totalElements ?? 0;
    //         // console.log("totalcount : " + totalCount);
    //         document.getElementById("member-total-count").textContent = `총 ${totalCount}건`;
    //     })
    //     .catch(err => {
    //         console.error("검색 실패:", err);
    //         const message = err.message || "알 수 없는 오류가 발생했습니다.";
    //         renderMemberTable(null);
    //
    //         if (err.status === 401) {
    //             alert("세션이 만료되었습니다. 다시 로그인 해주세요.");
    //             window.location.href = "/login";
    //         } else {
    //             alert(message);
    //         }
    //         return Promise.reject();
    //     });

}

function renderMembersTable(members, pageInfo) {

    console.log("------> renderMemberTable() start")
    console.log("members :  ", members);
    const tbody = document.getElementById("members-table-body");
    tbody.innerHTML = "";

    if (!members || members.length === 0) {
        tbody.innerHTML = "<tr><td colspan='11'>검색 결과가 없습니다.</td></tr>";
        return;
    }

    //-------------------------------------//
    //------- table body 생성 --------------//
    //-------------------------------------//

    members.forEach((item, index) => {
        const rowNumber = pageInfo.number * pageInfo.size + index + 1; // 1부터 시작하는 전체 순번
        const row = document.createElement("tr");
        console.log("item : ", item);
        row.innerHTML = `
            <td>${rowNumber}</td>
            <td style="color: blue; text-decoration: underline; cursor: pointer;">
                <a href="/site/members/${item._links.self.href.split('/').pop()}">
                ${item.memberId}
                </a>
            </td>
            <td>${item.phone}</td>
            <td>${item.bankName}</td>
            <td>${item.bankAccount}</td>
            <td>${item.bankAccountHolder || ""}</td>
            <td>${item.depositBankName || ""}</td>
            <td>${item.depositBankAccount || ""}</td>
            <td>${item.regDate ? item.regDate.substring(0, 10) : ""}</td>
            <td>${item.enabled ? "활성" : "비활성"}</td>
            <td>${item.deleted ? "삭제" : ""}</td>
      `;
        tbody.appendChild(row);
    });
}

function enabledMembersOnly(){
    const enabledCheckbox = document.getElementById("enabledCheckbox");
    const disabledCheckbox = document.getElementById("disabledCheckbox");
    const disabledLabel = document.getElementById("disabledLabel");

    if (enabledCheckbox.checked) {
        disabledLabel.style.opacity = enabledCheckbox.checked ? "0.5" : "1.0";
        // disabledCheckbox를 비활성화 (회색 처리 및 클릭 불가)
        disabledCheckbox.disabled = true;
        // 체크 상태도 해제
        disabledCheckbox.checked = false;
    } else {
        disabledLabel.style.opacity = enabledCheckbox.checked ? "0.5" : "1.0";
        // 체크 상태도 해제
        disabledCheckbox.checked = false;
        // 다시 활성화
        disabledCheckbox.disabled = false;
    }
}


