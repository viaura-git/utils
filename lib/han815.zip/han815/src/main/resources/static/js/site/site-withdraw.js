document.addEventListener("DOMContentLoaded", () => {
    getSiteBalance();

    const userIdInput = document.getElementById("userId");
    const userId = userIdInput?.value?.trim();

    if (userId) {
        getSiteAdmin(userId)
            .then()
            .catch((error) => {
                console.log("초기 멤버 정보 로딩 실패:", error);
            });
    }

    // 출금 버튼 클릭 핸들러
    document.getElementById("withdraw-button").addEventListener("click", () => {
        const payload = {
            memberMid: document.getElementById("user-uid").innerText,
            memberId: document.getElementById("user-id").innerText,
            withdrawalBankName: document.getElementById("withdrawal-bank-name").innerText,
            withdrawalBankCode: document.getElementById("withdrawal-bank-code").innerText,
            withdrawalBankAccount: document.getElementById("withdrawal-bank-account").innerText,
            withdrawalBankAccountHolder: document.getElementById("withdrawal-bank-account-holder").innerText,
            withdrawalBankIdentifier: document.getElementById("withdrawal-bank-identifier").innerText,
            withdrawalStatus: "NEW",
            type: "WITHDRAWAL",
            amount: parseInt(document.getElementById("amount").value)
        };

        console.log("====> payload : ", payload);

        fetch("/api/site/withdraw", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
        })
            .then(res => {
                if (!res.ok) throw new Error("출금 요청 실패");
                return res.json();
            })
            .then(data => {
                alert("출금 요청이 완료되었습니다.");
                console.log("응답:", data);
                window.location.href = "/site/members/withdrawals";
            })
            .catch(err => {
                console.error(err);
                alert("출금 요청 중 오류가 발생했습니다.");
            });
    });

    // 입력 시 자동 로딩
    userIdInput.addEventListener("change", () => {
        getSiteAdmin(userIdInput.value);
    });
});


async function loadTransactionPageFromUrl(url) {
    console.log("-----> loadTransactionPageFromUrl() start, url : ", url);
    const data = await fetchPage(url);
    console.log("loadTransactionPageFromUrl()  data : ", data);

    fillSiteAdminInfo(data);
}

async function getSiteAdmin(userId) {
    // memberId = memberId.trim();
    if (!userId) return; // 빈 값이면 요청하지 않음

    console.log("getMemberInfo() start, userId : ", userId);

    const params = new URLSearchParams();
    params.append("userId", userId);

    const url = '/api/site/users?'+params.toString();

    console.log("Final request URL --->", url);
    loadTransactionPageFromUrl(url);
}

function fillSiteAdminInfo(user) {
    const errorDiv = document.getElementById("withdraw-error-message");
    const infoDiv = document.getElementById("withdrawal-info");

    // 모두 초기화 (처음에 숨김)
    errorDiv.style.display = "none";
    infoDiv.style.display = "none";

    if (!user || user.length === 0) {
        console.log("----> no data");

        // 에러 메시지만 표시
        errorDiv.innerText = "해당 회원 정보를 찾을 수 없습니다.";
        errorDiv.style.display = "block";

        return;
    }

    // 에러 메시지 숨기고 정보 영역 보이기
    errorDiv.style.display = "none";
    infoDiv.style.display = "grid";  // 혹은 원래 사용하던 display

    // 값 채우기
    document.getElementById("user-uid").innerHTML = user.uid;
    document.getElementById("user-id").innerText = user.userId;
    document.getElementById("withdrawal-bank-name").innerText = user.bankName || "-";
    document.getElementById("withdrawal-bank-account").innerText = user.bankAccount || "-";
    document.getElementById("withdrawal-bank-code").innerText = user.bankCode || "-";
    document.getElementById("withdrawal-bank-account-holder").innerText = user.bankAccountHolder || "-";
    document.getElementById("withdrawal-bank-identifier").innerText = user.bankIdentifier || "-";
}









