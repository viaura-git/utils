function getSiteBalance() {
    fetch("/api/site/balance")
        .then(res => {
            if (!res.ok) {
                throw new Error("회원 정보를 불러오는 데 실패했습니다.");
            }
            return res.text(); // JSON이 아닐 수도 있으므로 먼저 text로 받아보기
        })
        .then(data => {
            console.log("balance data: ", data);
            document.getElementById("site-balance").innerHTML = parseInt(data).toLocaleString() + "원";
        })
        .catch(error => console.log(error));
}
