package com.viaura.han815;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Han815ApplicationTests {

    @Test
    void contextLoads() {
    }

}
