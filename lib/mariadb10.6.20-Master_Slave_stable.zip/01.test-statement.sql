CREATE TABLE testTable(
  id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(20) NOT NULL,
  createdat DATETIME DEFAULT CURRENT_TIMESTAMP,
  modifiedat DATETIME ON UPDATE CURRENT_TIMESTAMP
);


INSERT INTO testTable (name) VALUES ('smLee');

UPDATE testTable SET name='skLee';

DELETE from testTable where NAME='skLee';

SELECT now();