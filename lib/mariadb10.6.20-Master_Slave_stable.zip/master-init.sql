CREATE USER 'replica_user'@'%' identified by 'money';

GRANT PROCESS, REPLICATION CLIENT, SELECT ON *.* TO 'replica_user'@'%';

GRANT REPLICATION SLAVE ON *.* TO 'replica_user'@'%';

FLUSH PRIVILEGES;

--FLUSH TABLES WITH READ LOCK; -- 데이터를 고정하고 로그 파일 위치를 확인
