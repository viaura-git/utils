package com.twobros.moayo.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;

@SpringBootApplication
//@PropertySource("classpath:/site.properties") 여기에 사용하는 것은 바람직하지 않은
//Logging system failed to initialize using configuration from 'null'
//java.lang.IllegalStateException: UT015023: This Context has been already destroyed
public class MoayoApiServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoayoApiServerApplication.class, args);
	}

}
