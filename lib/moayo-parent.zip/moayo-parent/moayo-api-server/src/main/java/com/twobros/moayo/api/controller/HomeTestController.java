package com.twobros.moayo.api.controller;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.twobros.moayo.api.services.YoutubeService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/") //이게 붙으면 dispatcher Servlet으로 먼저 넘어간다. 없으면 index html로 바로 간다 
public class HomeTestController {
	
	@Autowired
	YoutubeService youtubeService;
	
	@GetMapping("")
	public ArrayList<HashMap<String, String>> viewHomeMain() {
		log.info("index start");
		ArrayList<HashMap<String, String>> result;
		try {
			result = youtubeService.getMostPopular();
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = null;
		}
		
		return result;
	}
	
}
