package com.twobros.moayo.api.models;

public enum ERole {
	
	ROLE_USER,
	ROLE_ADMIN,
	ROLE_MODERATOR

}
