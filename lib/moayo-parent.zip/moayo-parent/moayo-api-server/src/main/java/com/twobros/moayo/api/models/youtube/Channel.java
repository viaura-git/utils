package com.twobros.moayo.api.models.youtube;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Channel {
	
	private String id;
	private String title;
	private String thumbnailURL;
	private String customURL;
	
	private ChannelStatistics statistics;

}
