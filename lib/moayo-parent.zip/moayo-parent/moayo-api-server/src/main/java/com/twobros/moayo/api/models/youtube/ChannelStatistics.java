package com.twobros.moayo.api.models.youtube;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class ChannelStatistics {
	
	private int viewCount;
	private int subscriberCount;
	private boolean hiddenSubscriberCount;
	private int videoCount;

}
