package com.twobros.moayo.api.models.youtube;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Video {
	
	private String id;
	private String title;
	private String thumnailURL;
	private String publishedAt;

}
