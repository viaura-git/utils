package com.twobros.moayo.api.security.model;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class JwtResponse {
	
	private String token;
//	private String type;
	private Long id;
	private String username;
	private String email;
	List<String> roles = new ArrayList<String>();

}
