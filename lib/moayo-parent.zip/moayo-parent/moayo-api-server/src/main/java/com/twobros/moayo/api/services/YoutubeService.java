package com.twobros.moayo.api.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.thymeleaf.util.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.twobros.moayo.api.models.youtube.Channel;
import com.twobros.moayo.api.models.youtube.ChannelStatistics;
import com.twobros.moayo.api.models.youtube.Video;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class YoutubeService {
	
	@Value("${youtube.api.key}")
	private String apiKey;
	
	@Value("${youtube.mostpopular.url}")
	private String mostPopularUrl;
	
	@Value("${youtube.channels.url}")
	private String channelsUrl;
	
	
	public ArrayList<HashMap<String, String>> getMostPopular() throws JsonMappingException, JsonProcessingException {
		
		log.info("getMostPopular start");
		log.debug("apiKey : {}", apiKey);
			
		ResponseEntity<String> videoResponse = getMostPopularVideoInfo();
		log.debug("videoResponse : {}", videoResponse.getBody());
		
		ObjectMapper mapper = new ObjectMapper();
		JsonNode videoItems = mapper.readTree(videoResponse.getBody()).path("items");
		log.info("video size : {}", videoItems.size());
		
		//video 정보를 추려온다 
		Map<String, Video> videos = extractVideos(videoItems);
		
		//channel 정보를 가져온다
		ResponseEntity<String> channelResponse = getChannelInfo(videoItems);
		log.debug("channelResponse : {}", channelResponse.getBody());
		
		JsonNode channelItems = mapper.readTree(channelResponse.getBody()).path("items");
		log.info("channelResponse -> channelItems.size() : {}", channelItems.size());
		
		//채널 정보를 추려온다 
		Map<String, Channel> channels = extractChannels(channelResponse);
		
		//구독자수를 가져온다
		
		//video 정보와 조합한다
		ArrayList<HashMap<String, String>> result = new ArrayList<HashMap<String, String>>();
		
		for(JsonNode item: videoItems) {
			String videoId = item.path("id").asText();
			String channelId = item.path("snippet").path("channelId").asText();
			
			HashMap<String, String> resultUnit = new HashMap<String, String>();
				resultUnit.put("publishedAt", 			videos.get(videoId).getPublishedAt());
				resultUnit.put("videoId", 				videos.get(videoId).getId());
				resultUnit.put("videoTitle", 			videos.get(videoId).getTitle());
				resultUnit.put("videoThumbnailURL", 	videos.get(videoId).getThumnailURL());
				resultUnit.put("channelTitle", 			channels.get(channelId).getTitle());
				resultUnit.put("channelId", 			channels.get(channelId).getId());
				resultUnit.put("channelThumbnailURL", 	channels.get(channelId).getThumbnailURL());
				resultUnit.put("channelCustomURL", 		channels.get(channelId).getCustomURL());
				resultUnit.put("channelSubscriberCount", 	Integer.toString(channels.get(channelId).getStatistics().getSubscriberCount()));
			
			result.add(resultUnit);
		}
		log.debug("result : {}", result);
		
		return result;
		
	}
	
	private ResponseEntity<String> getMostPopularVideoInfo() {
		//curl -X GET "https://www.googleapis.com/youtube/v3/videos?part=snippet&chart=mostPopular&maxResults=25&key=AIzaSyAMQoWApmuOhj26D27uM4b46sCIq7ZRuF0"
		
		RestTemplate restTemplate = new RestTemplate();
		
		Map<String, String> params = new HashMap<String, String>();
			params.put("part", "snippet");
			params.put("key", 	apiKey);
			params.put("regionCode", "kr");
			params.put("chart", "mostPopular");
			params.put("maxResults", "24");
			
			
		return restTemplate.getForEntity(mostPopularUrl, String.class, params);
	}

	private Map<String, Video> extractVideos(JsonNode items) {
		
		HashMap<String, Video> videos = new HashMap<String, Video>();
		
		for (JsonNode item : items) {
			Video video = new Video();
				video.setId(item.path("id").asText());
				video.setTitle(item.path("snippet").path("localized").path("title").asText());
				video.setPublishedAt(item.path("snippet").path("publishedAt").asText());
				video.setThumnailURL(item.path("snippet").path("thumbnails").path("high").path("url").asText());
				
			videos.put(video.getId(), video);
		}
		
		log.info("videos : {}", videos.toString());
		
		return videos;
	}

	private Map<String, Channel> extractChannels(ResponseEntity<String> channelResponse) throws JsonMappingException, JsonProcessingException {
		
		ObjectMapper mapper = new ObjectMapper();
		JsonNode channelItems = mapper.readTree(channelResponse.getBody())
										.path("items");
		
		log.debug("channel size : {}", channelItems.size());
		
		
		HashMap<String, Channel> channels = new HashMap<String, Channel>();
		
		for(JsonNode item: channelItems) {
			Channel channel = new Channel();
				channel.setTitle(item.path("snippet").path("title").asText());
				channel.setId(item.path("id").asText());
				channel.setThumbnailURL(item.path("snippet").path("thumbnails").path("default").path("url").asText());
				channel.setCustomURL(item.path("snippet").path("customUrl").asText());
				
				log.debug("channel info: {}", channel.toString());
				
			ChannelStatistics statistics = new ChannelStatistics();
				statistics.setViewCount(item.path("statistics").path("viewCount").asInt());
				statistics.setSubscriberCount(item.path("statistics").path("subscriberCount").asInt());
				statistics.setHiddenSubscriberCount(item.path("statistics").path("hiddenSubscriberCount").asBoolean());
				statistics.setVideoCount(item.path("statistics").path("videoCount").asInt());
				
			channel.setStatistics(statistics);
			
			channels.put(channel.getId(), channel);
		}
		return channels;
	}

	
	
	public ResponseEntity<String> getChannelInfo(JsonNode videoItems) {
		
		
		//channel id만 추출 및 comma saperate string으로 변
		String csIds = extractChannelId(videoItems);
		log.debug("csChannelIds : {}", csIds);
		log.debug("videoItems size {}",videoItems.size());
		
		RestTemplate restTemplate = new RestTemplate();
		
		Map<String, String> params = new HashMap<String, String>();
			params.put("part",	"id,snippet,statistics");
			params.put("id", 	csIds);
			params.put("key", 	apiKey);
			
		ResponseEntity<String> channelResponse = restTemplate.getForEntity(channelsUrl, String.class, params);

			log.debug("result entity status code : {}", channelResponse.getStatusCode());
			log.debug("result entity headers : {}",channelResponse.getHeaders());
			log.debug("result entity body : {}",channelResponse.getBody());
			
		return channelResponse;
		
	}

	private String extractChannelId(JsonNode items) {
		
		ArrayList<String> ids = new ArrayList<String>();
		
		for (JsonNode item : items) {
			String id = item.path("snippet").path("channelId").asText();
			ids.add(id);
		}
		log.info("target channel count : {}", ids.size());
		
		return StringUtils.join(ids, ",");
	}
	

}
