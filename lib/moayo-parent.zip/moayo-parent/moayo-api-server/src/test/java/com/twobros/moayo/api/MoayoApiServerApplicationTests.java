package com.twobros.moayo.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoayoApiServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
