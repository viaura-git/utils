package com.twobros.moayo.batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class MoayoBatchServerApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(MoayoBatchServerApplication.class, args);
	}

}
